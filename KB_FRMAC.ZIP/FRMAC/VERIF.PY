#!/usr/bin/env python3
"""Verifie la structure d'un KEYBOARD.SYS (format MS-DOS 3.3-6.22) et
simule la logique d'etat de KEYB pour quelques touches."""
import struct, sys

data = open(sys.argv[1], 'rb').read()
cp = int(sys.argv[2]) if len(sys.argv) > 2 else 850
w = lambda o: struct.unpack_from('<H', data, o)[0]
d = lambda o: struct.unpack_from('<I', data, o)[0]

assert data[:8] == b'\xffKEYB   ', 'signature'
max_com, max_spec, max_logic = w(16), w(18), w(20)
n_ids, n_langs = w(24), w(26)
p = 28
langs = {}
for _ in range(n_langs):
    langs[data[p:p+2].decode()] = d(p+2); p += 6
ids = {}
for _ in range(n_ids):
    ids[w(p)] = d(p+2); p += 6
print('max commun/specifique/logique :', max_com, max_spec, max_logic)
print('langues', langs, 'ID', ids)

le = langs['FR']
logic = d(le+4)
ncp = data[le+9]
cps = {w(le+10+6*i): d(le+12+6*i) for i in range(ncp)}
llen = w(logic)
assert llen <= max_logic
common = logic + llen
clen = w(common)
assert clen <= max_com and w(common+2) == 0xFFFF
for c, o in cps.items():
    assert w(o+2) == c and w(o) <= max_spec, c

def states(sect):
    """Retourne {state_id: [(kbtype, err, tables)]}"""
    out = {}
    o = sect + 4
    while True:
        slen = w(o)
        if slen == 0: break
        sid, kb, err = data[o+2], w(o+3), data[o+5:o+7]
        t = o + 7
        tabs = []
        if sid in (1, 2, 24):           # tables de drapeaux
            n = w(t); t += 2
            tabs.append(('flag', [(data[t+3*i], data[t+3*i+1], data[t+3*i+2]) for i in range(n)]))
            t += 3*n
        else:
            while True:
                tsz = w(t)
                if tsz == 0: t += 2; break
                opt, n = data[t+2], data[t+3]
                esz = 2 if opt & 0x80 else 3
                assert opt & 0x40, 'type 1 non gere'
                ents = [tuple(data[t+4+esz*i:t+4+esz*(i+1)]) for i in range(n)]
                assert tsz == 4 + esz*n, (sid, tsz, n)
                tabs.append((opt, ents))
                t += tsz
        assert t == o + slen, ('longueur etat', sid, t-o, slen)
        out.setdefault(sid, []).append((kb, err, tabs))
        o += slen
    assert o + 2 == sect + w(sect), 'longueur section'
    return out

com = states(common)
spec = states(cps[cp])

# ---------------- simulation de la logique ---------------------------------
# bits utilises (POSTEQU / KEYBSHAR)
FLAGS = {(4,0x80):'SHIFT', (4,0x40):'CTL', (4,0x20):'ALT', (4,0x08):'MATCH',
         (0,0x40):'CAPS', (0,0x20):'NUM', (0,0x08):'ALTK', (3,0x08):'RALT',
         (3,0x02):'E0', (5,0x80):'ACUTE', (5,0x40):'GRAVE', (5,0x20):'DIA',
         (5,0x10):'CIRC', (5,0x04):'TILDE'}

def lookup(sid, scan):
    for sect in (spec, com):
        for kb, err, tabs in sect.get(sid, []):
            if not kb & 0x1000:   # G_KB
                continue
            for opt, ents in tabs:
                for e in ents:
                    if opt == 'flag':
                        if e[0] == scan: return ('flag', e[1], e[2])
                    elif e[0] == scan:
                        return ('char', e[1])
    return None

def errchar(sid):
    for sect in (spec, com):
        for kb, err, tabs in sect.get(sid, []):
            return err[0]

def run(scan, mods, nls):
    """mods : ensemble de SHIFT CTL ALT RALT CAPS ; nls : drapeaux morts."""
    st = set(mods) | set(nls)
    if 'RALT' in st or 'ALT' in st: st |= {'ALT', 'ALTK'}
    pc = logic + 4
    end = logic + llen
    cond = [True]; out = []
    exit_if_found = False
    while pc < end:
        op = data[pc]; cmd = op & 0xF0
        if cmd in (0x00, 0x10):   # IFF / ANDF
            fid, mask = op & 7, data[pc+1]
            v = FLAGS[(fid, mask)] in st
            if op & 8: v = not v
            if cmd == 0x00: cond.append(cond[-1] and v)
            else: cond[-1] = cond[-1] and v
            pc += 2; continue
        if cmd == 0x20:           # ELSEF
            cond[-1] = cond[-2] and not cond[-1]; pc += 1; continue
        if cmd == 0x30:
            cond.pop(); pc += 1; continue
        if cmd == 0x80:           # IFKBD (on simule G_KB)
            cond.append(cond[-1] and bool(w(pc+1) & 0x1000)); pc += 3; continue
        if not cond[-1]:
            pc += {0x40:2, 0x50:2, 0x60:2, 0x70:2, 0x90:3, 0xA0:1, 0xB0:1, 0xC0:1}[cmd]
            continue
        if cmd == 0x50: exit_if_found = True; pc += 2; continue
        if cmd in (0x40, 0x60):   # XLATT / SET_FLAG
            r = lookup(data[pc+1], scan)
            if r:
                if r[0] == 'flag':
                    return ('mort', {0x80:'aigu',0x40:'grave',0x20:'trema',0x10:'circ',0x04:'tilde'}[r[2]])
                return ('car', r[1])
            pc += 2; continue
        if cmd == 0x70:
            out.append(errchar(data[pc+1])); pc += 2; continue
        if cmd == 0xA0: out.append('BIP'); pc += 1; continue
        if cmd == 0xB0:
            for f in ('ACUTE','GRAVE','DIA','CIRC','TILDE'): st.discard(f)
            pc += 1; continue
        if cmd == 0x90:
            off = struct.unpack_from('<h', data, pc+1)[0]
            if op & 0x0F: return ('bios', out)
            pc = pc + 3 + off; continue
        raise ValueError(hex(op))
    return ('bios', out)

enc = 'cp437' if cp == 437 else 'cp850'
def show(r):
    if r[0] == 'car': return bytes([r[1]]).decode(enc)
    if r[0] == 'mort': return '[' + r[1] + ']'
    return '(BIOS)' + ''.join(bytes([c]).decode(enc) if isinstance(c,int) else '!' for c in r[1])

if __name__ == '__main__':
    noms = {41:'0x29', 86:'0x56'}
    rows = [41,86] + list(range(2,14)) + list(range(16,28)) + list(range(30,41)) + [43] + list(range(44,54))
    cols = [((), 'normal'), (('SHIFT',), 'Maj'), (('CAPS',), 'VerrMaj'),
            (('RALT',), 'Opt'), (('RALT','SHIFT'), 'Maj+Opt')]
    print('%-6s' % 'scan' + ''.join('%-10s' % c[1] for c in cols))
    for s in rows:
        print('%-6s' % noms.get(s, s) + ''.join('%-10s' % show(run(s, m, ())) for m, _ in cols))
    print()
    tests = [('^ puis e', 26, (), 'CIRC', 18, ()), ('^ puis E', 26, (), 'CIRC', 18, ('SHIFT',)),
             ('trema puis i', 26, ('SHIFT',), 'DIA', 23, ()), ('` puis a', 43, (), 'GRAVE', 16, ()),
             ('` puis A', 43, (), 'GRAVE', 16, ('SHIFT',)), ('Opt+n puis n', 49, ('RALT',), 'TILDE', 49, ()),
             ('Opt+n puis espace', 49, ('RALT',), 'TILDE', 57, ()), ('^ puis espace', 26, (), 'CIRC', 57, ()),
             ('^ puis x (invalide)', 26, (), 'CIRC', 45, ())]
    for nom, k1, m1, flag, k2, m2 in tests:
        r1 = run(k1, m1, ())
        assert r1[0] == 'mort', (nom, r1)
        print('%-22s -> %s' % (nom, show(run(k2, m2, (flag,)))))
    print('Alt gauche+A ->', run(16, ('ALT',), ()))
    print('Ctrl+A       ->', run(16, ('CTL',), ()))
