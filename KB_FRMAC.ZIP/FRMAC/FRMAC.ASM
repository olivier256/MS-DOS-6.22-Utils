	PAGE	,132
	TITLE	FRMAC - Fichier de definition clavier AZERTY Mac pour KEYB
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; FRMAC.SYS - disposition AZERTY Apple (Mac francais) pour KEYB de MS-DOS
;;
;; Derive de KDFNOW.ASM et KDFFR189.ASM (sources MS-DOS 4.0, licence MIT,
;; (c) Microsoft Corporation).
;;
;; Fichier mono-langue : un seul code pays (FR), un seul ID (189),
;; deux pages de codes (437 et 850).
;;
;; Utilisation :   KEYB FR,850,C:\DOS\FRMAC.SYS /ID:189
;;
;; Assemblage avec Borland Turbo Assembler (2.0 ou plus) et TLINK :
;;   tasm /iINC FRMAC.ASM
;;   tlink /t FRMAC.OBJ
;;   ren FRMAC.COM FRMAC.SYS
;; Variante sans echange des touches ISO :
;;   tasm /iINC /dMAC_SWAP=0 FRMAC.ASM,FRMACN.OBJ
;;   tlink /t FRMACN.OBJ
;;   ren FRMACN.COM FRMACN.SYS
;;
;; Avec MASM 5.1 : masm /IINC FRMAC; link FRMAC; exe2bin FRMAC FRMAC.SYS
;; Avec JWasm    : jwasm -bin -Iinc -Fo=FRMAC.SYS FRMAC.ASM
;;
;; Le fichier est assemble a l'origine 100h (format .COM, pour TLINK /t) ;
;; tous les pointeurs internes sont donc exprimes relativement a FILE_START,
;; ce qui donne des offsets de fichier corrects quel que soit l'outil.
;;
;; Couches :
;;   normal / Maj            : legendes du clavier Mac
;;   Option droite (AltGr)    : 3e niveau Mac        (etat THIRD_SHIFT)
;;   Maj + Option droite      : 4e niveau Mac        (etat FOURTH_SHIFT)
;;   Option gauche            : Alt PC (menus de Word, Alt+lettre)
;;   Verr. Maj                : majuscules ; sur la rangee du haut donne
;;                              E accent aigu, E grave, C cedille, A grave
;;                              (et U grave) au lieu des chiffres, comme le Mac
;;
;; Touches mortes : ^ et trema (touche a droite du P), accent grave
;; (touche a gauche d'Entree, ISO), tilde (Option droite + N).
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

	INCLUDE KEYBSHAR.INC
	INCLUDE POSTEQU.INC
	INCLUDE KEYBMAC.INC

STANDARD_TABLE	    EQU   TYPE_2_TAB+ASCII_ONLY
CAPS_ACCENT	    EQU   38	       ;; etat maison : Verr. Maj sur e,e,c,a,u
ALL_KB		    EQU   G_KB+P12_KB+AT_KB+XT_KB

;;---------------------------------------------------------------------------
;; Position des deux touches ISO.
;; Sur les Mac ISO, macOS inverse la touche a gauche du 1 (@ #) et la touche
;; a cote du Maj gauche (< >). Sous QEMU/UTM, elles arrivent donc a DOS
;; avec les codes de balayage echanges. MAC_SWAP=1 corrige cela.
;; Si @ et < sont inverses chez vous, assemblez avec -DMAC_SWAP=0.
;;---------------------------------------------------------------------------
IFNDEF MAC_SWAP
MAC_SWAP	    EQU   1
ENDIF
IF MAC_SWAP
K_AT		    EQU   86	       ;; touche @ # (a gauche du 1)
K_LT		    EQU   41	       ;; touche < > (a cote de Maj gauche)
ELSE
K_AT		    EQU   41
K_LT		    EQU   86
ENDIF

CODE	SEGMENT PUBLIC 'CODE'
	ASSUME CS:CODE,DS:CODE
	ORG    100h
FILE_START:

;;***************************************************************************
;; En-tete du fichier
;;***************************************************************************
DB   0FFh,'KEYB   '                  ;; signature
DB   8 DUP(0)			     ;; reserve
DW   COMMON_XLAT_END-FR_COMMON_XLAT  ;; taille max section commune
DW   CP850_XLAT_END-FR_850_XLAT      ;; taille max section specifique
DW   LOGIC_END-FR_LOGIC 	     ;; taille max logique d'etat
DW   0				     ;; reserve
DW   1				     ;; nombre d'ID
DW   1				     ;; nombre de langues
DB   'FR'                            ;; table des codes langue
DW   FR_LANG_ENT-FILE_START,0	     ;;
DW   189			     ;; table des ID
DW   FR_LANG_ENT-FILE_START,0	     ;;

;;***************************************************************************
;; Entree de langue
;;***************************************************************************
FR_LANG_ENT:
   DB	'FR'                         ;; code langue
   DW	189			     ;; ID
   DW	FR_LOGIC-FILE_START,0	     ;; logique d'etat
   DB	1			     ;; nombre d'ID
   DB	2			     ;; nombre de pages de codes
   DW	437
   DW	FR_437_XLAT-FILE_START,0
   DW	850
   DW	FR_850_XLAT-FILE_START,0

;;***************************************************************************
;; Logique d'etat
;;***************************************************************************
FR_LOGIC:
   DW  LOGIC_END-$		       ;; longueur
   DW  0			       ;; pas de verrouillage "machine a ecrire"

   KOPTION EXIT_IF_FOUND

;; --- Pose des drapeaux de touches mortes (avant les traductions) ---------
   IFF	EITHER_CTL,NOT
      IFF  EITHER_ALT,NOT
	 IFF EITHER_SHIFT
	    SET_FLAG DEAD_UPPER
	 ELSEF
	    SET_FLAG DEAD_LOWER
	 ENDIFF
      ELSEF
	 IFF  R_ALT_SHIFT
	 ANDF EITHER_SHIFT,NOT
	    SET_FLAG DEAD_THIRD
	 ENDIFF
      ENDIFF
   ENDIFF

;; --- Trema -----------------------------------------------------------------
DIARESIS_PROC:
   IFF DIARESIS,NOT
      KGOTO GRAVE_PROC
   ENDIFF
      RESET_NLS
      IFF R_ALT_SHIFT,NOT
	 XLATT DIARESIS_SPACE
      ENDIFF
      IFF EITHER_CTL,NOT
      ANDF EITHER_ALT,NOT
	 IFF EITHER_SHIFT
	    IFF CAPS_STATE
	       XLATT DIARESIS_LOWER
	    ELSEF
	       XLATT DIARESIS_UPPER
	    ENDIFF
	 ELSEF
	    IFF CAPS_STATE
	       XLATT DIARESIS_UPPER
	    ELSEF
	       XLATT DIARESIS_LOWER
	    ENDIFF
	 ENDIFF
      ENDIFF
      PUT_ERROR_CHAR DIARESIS_SPACE
      BEEP
      KGOTO NON_DEAD

;; --- Accent grave ----------------------------------------------------------
GRAVE_PROC:
   IFF GRAVE,NOT
      KGOTO CIRCUMFLEX_PROC
   ENDIFF
      RESET_NLS
      IFF R_ALT_SHIFT,NOT
	 XLATT GRAVE_SPACE
      ENDIFF
      IFF EITHER_CTL,NOT
      ANDF EITHER_ALT,NOT
	 IFF EITHER_SHIFT
	    IFF CAPS_STATE
	       XLATT GRAVE_LOWER
	    ELSEF
	       XLATT GRAVE_UPPER
	    ENDIFF
	 ELSEF
	    IFF CAPS_STATE
	       XLATT GRAVE_UPPER
	    ELSEF
	       XLATT GRAVE_LOWER
	    ENDIFF
	 ENDIFF
      ENDIFF
      PUT_ERROR_CHAR GRAVE_SPACE
      BEEP
      KGOTO NON_DEAD

;; --- Accent circonflexe ----------------------------------------------------
CIRCUMFLEX_PROC:
   IFF CIRCUMFLEX,NOT
      KGOTO TILDE_PROC
   ENDIFF
      RESET_NLS
      IFF R_ALT_SHIFT,NOT
	 XLATT CIRCUMFLEX_SPACE
      ENDIFF
      IFF EITHER_CTL,NOT
      ANDF EITHER_ALT,NOT
	 IFF EITHER_SHIFT
	    IFF CAPS_STATE
	       XLATT CIRCUMFLEX_LOWER
	    ELSEF
	       XLATT CIRCUMFLEX_UPPER
	    ENDIFF
	 ELSEF
	    IFF CAPS_STATE
	       XLATT CIRCUMFLEX_UPPER
	    ELSEF
	       XLATT CIRCUMFLEX_LOWER
	    ENDIFF
	 ENDIFF
      ENDIFF
      PUT_ERROR_CHAR CIRCUMFLEX_SPACE
      BEEP
      KGOTO NON_DEAD

;; --- Tilde (Option droite + N) --------------------------------------------
TILDE_PROC:
   IFF TILDE,NOT
      KGOTO NON_DEAD
   ENDIFF
      RESET_NLS
      IFF R_ALT_SHIFT,NOT
	 XLATT TILDE_SPACE
      ENDIFF
      IFF EITHER_CTL,NOT
      ANDF EITHER_ALT,NOT
	 IFF EITHER_SHIFT
	    IFF CAPS_STATE
	       XLATT TILDE_LOWER
	    ELSEF
	       XLATT TILDE_UPPER
	    ENDIFF
	 ELSEF
	    IFF CAPS_STATE
	       XLATT TILDE_UPPER
	    ELSEF
	       XLATT TILDE_LOWER
	    ENDIFF
	 ENDIFF
      ENDIFF
      PUT_ERROR_CHAR TILDE_SPACE
      BEEP
      KGOTO NON_DEAD

;; --- Niveaux 1 a 4 ---------------------------------------------------------
NON_DEAD:
   IFKBD G_KB+P12_KB		       ;; ne pas traduire le "/" du pave
   ANDF LC_E0			       ;;  numerique (prefixe E0)
      EXIT_STATE_LOGIC
   ENDIFF

   IFF EITHER_CTL,NOT		       ;; Alt gauche seul : cas Alt
      IFF  ALT_SHIFT
      ANDF R_ALT_SHIFT,NOT
	 XLATT ALT_CASE
      ENDIFF
   ELSEF
      IFF EITHER_ALT,NOT	       ;; Ctrl seul : cas Ctrl
	 XLATT CTRL_CASE
      ENDIFF
   ENDIFF

   IFF	EITHER_ALT,NOT
   ANDF EITHER_CTL,NOT
      IFF EITHER_SHIFT		       ;; Maj
	  IFF NUM_STATE,NOT
	      XLATT NUMERIC_PAD
	  ENDIFF
	  IFF CAPS_STATE
	      XLATT ALPHA_LOWER
	  ELSEF
	      XLATT ALPHA_UPPER
	  ENDIFF
	  XLATT NON_ALPHA_UPPER
      ELSEF			       ;; sans Maj
	  IFF NUM_STATE
	      XLATT NUMERIC_PAD
	  ENDIFF
	  IFF CAPS_STATE
	      XLATT ALPHA_UPPER
	      XLATT CAPS_ACCENT
	  ELSEF
	      XLATT ALPHA_LOWER
	  ENDIFF
	  XLATT NON_ALPHA_LOWER
      ENDIFF
   ELSEF
      IFF  EITHER_CTL,NOT	       ;; Option droite = AltGr
      ANDF R_ALT_SHIFT
	  IFF EITHER_SHIFT
	      XLATT FOURTH_SHIFT
	  ELSEF
	      XLATT THIRD_SHIFT
	  ENDIFF
      ENDIFF
   ENDIFF

   EXIT_STATE_LOGIC

LOGIC_END:

;;***************************************************************************
;; Section de traduction commune (identique en 437 et 850)
;;***************************************************************************
FR_COMMON_XLAT:
   DW	 COMMON_XLAT_END-$	       ;; longueur de la section
   DW	 -1			       ;; page de codes : commune

;; --- Drapeaux : touches mortes sans modificateur --------------------------
   DW	 COM_DK_LO_END-$
   DB	 DEAD_LOWER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 2
   DB	 26			       ;; ^
   FLAG  CIRCUMFLEX
   DB	 43			       ;; ` (a gauche d'Entree)
   FLAG  GRAVE
COM_DK_LO_END:

;; --- Drapeaux : touches mortes avec Maj -----------------------------------
   DW	 COM_DK_UP_END-$
   DB	 DEAD_UPPER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 1
   DB	 26			       ;; trema
   FLAG  DIARESIS
COM_DK_UP_END:

;; --- Drapeaux : touches mortes avec Option droite -------------------------
   DW	 COM_DK_TH_END-$
   DB	 DEAD_THIRD
   DW	 ALL_KB
   DB	 -1,-1
   DW	 1
   DB	 49			       ;; N -> tilde
   FLAG  TILDE
COM_DK_TH_END:

;; --- Cas Alt (Option gauche) : Alt+lettre selon AZERTY ---------------------
   DW	 COM_ALT_END-$
   DB	 ALT_CASE
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_ALT_T_END-$
   DB	 TYPE_2_TAB
   DB	 6
   DB	 16,0,1EH		       ;; Alt+A
   DB	 17,0,2CH		       ;; Alt+Z
   DB	 30,0,10H		       ;; Alt+Q
   DB	 39,0,32H		       ;; Alt+M
   DB	 44,0,11H		       ;; Alt+W
   DB	 50,-1,-1		       ;; position du M US : rien
COM_ALT_T_END:
   DW	 0
COM_ALT_END:

;; --- Cas Ctrl ---------------------------------------------------------------
   DW	 COM_CTRL_END-$
   DB	 CTRL_CASE
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_CTRL_T_END-$
   DB	 TYPE_2_TAB
   DB	 9
   DB	 12,-1,-1		       ;; pas de Ctrl+- US
   DB	 07,30,07		       ;; Ctrl+touche 6 -> RS
   DB	 13,31,13		       ;; Ctrl+- -> US
   DB	 16,01,16		       ;; Ctrl+A
   DB	 17,26,17		       ;; Ctrl+Z
   DB	 30,17,30		       ;; Ctrl+Q
   DB	 39,13,39		       ;; Ctrl+M
   DB	 44,23,44		       ;; Ctrl+W
   DB	 50,-1,-1		       ;; position du M US : rien
COM_CTRL_T_END:
   DW	 0
COM_CTRL_END:

;; --- Lettres minuscules qui different de QWERTY ---------------------------
   DW	 COM_AL_LO_END-$
   DB	 ALPHA_LOWER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_AL_LO_T_END-$
   DB	 STANDARD_TABLE
   DB	 5
   DB	 16,'a'
   DB	 17,'z'
   DB	 30,'q'
   DB	 39,'m'
   DB	 44,'w'
COM_AL_LO_T_END:
   DW	 0
COM_AL_LO_END:

;; --- Lettres majuscules qui different de QWERTY ---------------------------
   DW	 COM_AL_UP_END-$
   DB	 ALPHA_UPPER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_AL_UP_T_END-$
   DB	 STANDARD_TABLE
   DB	 5
   DB	 16,'A'
   DB	 17,'Z'
   DB	 30,'Q'
   DB	 39,'M'
   DB	 44,'W'
COM_AL_UP_T_END:
   DW	 0
COM_AL_UP_END:

;; --- Verr. Maj sur la rangee du haut (partie commune) ---------------------
   DW	 COM_CA_END-$
   DB	 CAPS_ACCENT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_CA_T_END-$
   DB	 STANDARD_TABLE
   DB	 2
   DB	  3,090H		       ;; E accent aigu
   DB	 10,080H		       ;; C cedille
COM_CA_T_END:
   DW	 0
COM_CA_END:

;; --- Niveau 1 (sans modificateur) -----------------------------------------
   DW	 COM_NA_LO_END-$
   DB	 NON_ALPHA_LOWER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_NA_LO_T_END-$
   DB	 STANDARD_TABLE
   DB	 19
   DB	 K_AT,'@'
   DB	  2,'&'
   DB	  3,082H		       ;; e accent aigu
   DB	  4,22H 		       ;; guillemet droit
   DB	  5,27H 		       ;; apostrophe
   DB	  6,'('
   DB	  8,08AH		       ;; e accent grave
   DB	  9,'!'
   DB	 10,087H		       ;; c cedille
   DB	 11,085H		       ;; a accent grave
   DB	 12,')'
   DB	 13,'-'
   DB	 27,'$'
   DB	 40,097H		       ;; u accent grave
   DB	 K_LT,'<'
   DB	 50,','
   DB	 51,';'
   DB	 52,':'
   DB	 53,'='
COM_NA_LO_T_END:
   DW	 0
COM_NA_LO_END:

;; --- Niveau 2 (Maj) -------------------------------------------------------
   DW	 COM_NA_UP_END-$
   DB	 NON_ALPHA_UPPER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_NA_UP_T_END-$
   DB	 STANDARD_TABLE
   DB	 21
   DB	 K_AT,'#'
   DB	  2,'1'
   DB	  3,'2'
   DB	  4,'3'
   DB	  5,'4'
   DB	  6,'5'
   DB	  7,'6'
   DB	  8,'7'
   DB	  9,'8'
   DB	 10,'9'
   DB	 11,'0'
   DB	 12,0F8H		       ;; degre
   DB	 13,'_'
   DB	 27,'*'
   DB	 40,'%'
   DB	 43,09CH		       ;; livre sterling
   DB	 K_LT,'>'
   DB	 50,'?'
   DB	 51,'.'
   DB	 52,'/'
   DB	 53,'+'
COM_NA_UP_T_END:
   DW	 0
COM_NA_UP_END:

;; --- Niveau 3 (Option droite) : partie commune 437/850 ----------------------
   DW	 COM_TH_END-$
   DB	 THIRD_SHIFT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_TH_T_END-$
   DB	 STANDARD_TABLE
   DB	 15
   DB	  3,089H		       ;; e trema
   DB	  6,'{'
   DB	  8,0AEH		       ;; guillemet ouvrant
   DB	  9,0ADH		       ;; point d'exclamation renverse
   DB	 10,080H		       ;; C cedille
   DB	 12,'}'
   DB	 16,091H		       ;; ae
   DB	 18,088H		       ;; e circonflexe
   DB	 23,08CH		       ;; i circonflexe
   DB	 33,09FH		       ;; f crosse (florin)
   DB	 38,0AAH		       ;; negation
   DB	 39,0E6H		       ;; micro
   DB	 48,0E1H		       ;; eszett
   DB	 52,0F6H		       ;; division
   DB	 22,0A7H		       ;; o ordinal
COM_TH_T_END:
   DW	 0
COM_TH_END:

;; --- Niveau 4 (Maj + Option droite) : partie commune 437/850 ----------------
   DW	 COM_FO_END-$
   DB	 FOURTH_SHIFT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 COM_FO_T_END-$
   DB	 STANDARD_TABLE
   DB	 8
   DB	  6,'['
   DB	  8,0AFH		       ;; guillemet fermant
   DB	 12,']'
   DB	 16,092H		       ;; AE
   DB	 38,'|'
   DB	 50,0A8H		       ;; point d'interrogation renverse
   DB	 52,5CH 		       ;; barre oblique inverse
   DB	 53,0F1H		       ;; plus ou moins
COM_FO_T_END:
   DW	 0
COM_FO_END:

;; --- Circonflexe ----------------------------------------------------------
   DW	 COM_CI_LO_END-$
   DB	 CIRCUMFLEX_LOWER
   DW	 ALL_KB
   DB	 94,0			       ;; caractere d'erreur : ^ seul
   DW	 COM_CI_LO_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 5
   DB	 16,083H		       ;; a
   DB	 18,088H		       ;; e
   DB	 23,08CH		       ;; i
   DB	 24,093H		       ;; o
   DB	 22,096H		       ;; u
COM_CI_LO_T_END:
   DW	 0
COM_CI_LO_END:

   DW	 COM_CI_SP_END-$
   DB	 CIRCUMFLEX_SPACE
   DW	 ALL_KB
   DB	 94,0
   DW	 COM_CI_SP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 1
   DB	 57,94			       ;; espace -> ^
COM_CI_SP_T_END:
   DW	 0
COM_CI_SP_END:

;; --- Trema ----------------------------------------------------------------
   DW	 COM_DI_LO_END-$
   DB	 DIARESIS_LOWER
   DW	 ALL_KB
   DB	 249,0
   DW	 COM_DI_LO_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 6
   DB	 16,084H		       ;; a
   DB	 18,089H		       ;; e
   DB	 23,08BH		       ;; i
   DB	 24,094H		       ;; o
   DB	 22,081H		       ;; u
   DB	 21,098H		       ;; y
COM_DI_LO_T_END:
   DW	 0
COM_DI_LO_END:

   DW	 COM_DI_UP_END-$
   DB	 DIARESIS_UPPER
   DW	 ALL_KB
   DB	 249,0
   DW	 COM_DI_UP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 3
   DB	 16,08EH		       ;; A
   DB	 24,099H		       ;; O
   DB	 22,09AH		       ;; U
COM_DI_UP_T_END:
   DW	 0
COM_DI_UP_END:

   DW	 COM_DI_SP_END-$
   DB	 DIARESIS_SPACE
   DW	 ALL_KB
   DB	 249,0
   DW	 COM_DI_SP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 1
   DB	 57,249
COM_DI_SP_T_END:
   DW	 0
COM_DI_SP_END:

;; --- Grave ----------------------------------------------------------------
   DW	 COM_GR_LO_END-$
   DB	 GRAVE_LOWER
   DW	 ALL_KB
   DB	 96,0
   DW	 COM_GR_LO_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 5
   DB	 16,085H		       ;; a
   DB	 18,08AH		       ;; e
   DB	 23,08DH		       ;; i
   DB	 24,095H		       ;; o
   DB	 22,097H		       ;; u
COM_GR_LO_T_END:
   DW	 0
COM_GR_LO_END:

   DW	 COM_GR_SP_END-$
   DB	 GRAVE_SPACE
   DW	 ALL_KB
   DB	 96,0
   DW	 COM_GR_SP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 1
   DB	 57,96			       ;; espace -> `
COM_GR_SP_T_END:
   DW	 0
COM_GR_SP_END:

;; --- Tilde ----------------------------------------------------------------
   DW	 COM_TI_LO_END-$
   DB	 TILDE_LOWER
   DW	 ALL_KB
   DB	 126,0
   DW	 COM_TI_LO_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 1
   DB	 49,0A4H		       ;; n
COM_TI_LO_T_END:
   DW	 0
COM_TI_LO_END:

   DW	 COM_TI_UP_END-$
   DB	 TILDE_UPPER
   DW	 ALL_KB
   DB	 126,0
   DW	 COM_TI_UP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 1
   DB	 49,0A5H		       ;; N
COM_TI_UP_T_END:
   DW	 0
COM_TI_UP_END:

   DW	 COM_TI_SP_END-$
   DB	 TILDE_SPACE
   DW	 ALL_KB
   DB	 126,0
   DW	 COM_TI_SP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 1
   DB	 57,126 		       ;; espace -> ~
COM_TI_SP_T_END:
   DW	 0
COM_TI_SP_END:

   DW	 0			       ;; dernier etat
COMMON_XLAT_END:

;;***************************************************************************
;; Section specifique page de codes 437
;;***************************************************************************
FR_437_XLAT:
   DW	 CP437_XLAT_END-$
   DW	 437

   DW	 CP437_NA_LO_END-$
   DB	 NON_ALPHA_LOWER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 CP437_NA_LO_T_END-$
   DB	 STANDARD_TABLE
   DB	 1
   DB	  7,015H		       ;; paragraphe (section)
CP437_NA_LO_T_END:
   DW	 0
CP437_NA_LO_END:

   DW	 CP437_TH_END-$
   DB	 THIRD_SHIFT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 CP437_TH_T_END-$
   DB	 STANDARD_TABLE
   DB	 1
   DB	  7,014H		       ;; pied de mouche
CP437_TH_T_END:
   DW	 0
CP437_TH_END:

   DW	 CP437_FO_END-$
   DB	 FOURTH_SHIFT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 CP437_FO_T_END-$
   DB	 STANDARD_TABLE
   DB	 1
   DB	 46,09BH		       ;; cent
CP437_FO_T_END:
   DW	 0
CP437_FO_END:

   DW	 0
CP437_XLAT_END:

;;***************************************************************************
;; Section specifique page de codes 850
;;***************************************************************************
FR_850_XLAT:
   DW	 CP850_XLAT_END-$
   DW	 850

;; --- Niveau 1 : paragraphe -------------------------------------------------
   DW	 CP850_NA_LO_END-$
   DB	 NON_ALPHA_LOWER
   DW	 ALL_KB
   DB	 -1,-1
   DW	 CP850_NA_LO_T_END-$
   DB	 STANDARD_TABLE
   DB	 1
   DB	  7,0F5H		       ;; paragraphe (section)
CP850_NA_LO_T_END:
   DW	 0
CP850_NA_LO_END:

;; --- Verr. Maj : E grave, A grave, U grave ---------------------------------
   DW	 CP850_CA_END-$
   DB	 CAPS_ACCENT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 CP850_CA_T_END-$
   DB	 STANDARD_TABLE
   DB	 3
   DB	  8,0D4H		       ;; E grave
   DB	 11,0B7H		       ;; A grave
   DB	 40,0EBH		       ;; U grave
CP850_CA_T_END:
   DW	 0
CP850_CA_END:

;; --- Niveau 3 (Option droite) ---------------------------------------------
   DW	 CP850_TH_END-$
   DB	 THIRD_SHIFT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 CP850_TH_T_END-$
   DB	 STANDARD_TABLE
   DB	 4
   DB	  7,0F4H		       ;; pied de mouche
   DB	 11,09BH		       ;; o barre
   DB	 19,0A9H		       ;; marque deposee
   DB	 46,0B8H		       ;; copyright
CP850_TH_T_END:
   DW	 0
CP850_TH_END:

;; --- Niveau 4 (Maj + Option droite) ---------------------------------------
   DW	 CP850_FO_END-$
   DB	 FOURTH_SHIFT
   DW	 ALL_KB
   DB	 -1,-1
   DW	 CP850_FO_T_END-$
   DB	 STANDARD_TABLE
   DB	 2
   DB	 11,09DH		       ;; O barre
   DB	 46,0BDH		       ;; cent
CP850_FO_T_END:
   DW	 0
CP850_FO_END:

;; --- Majuscules accentuees absentes de la 437 -----------------------------
   DW	 CP850_CI_UP_END-$
   DB	 CIRCUMFLEX_UPPER
   DW	 ALL_KB
   DB	 94,0
   DW	 CP850_CI_UP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 5
   DB	 16,0B6H		       ;; A
   DB	 18,0D2H		       ;; E
   DB	 23,0D7H		       ;; I
   DB	 24,0E2H		       ;; O
   DB	 22,0EAH		       ;; U
CP850_CI_UP_T_END:
   DW	 0
CP850_CI_UP_END:

   DW	 CP850_DI_UP_END-$
   DB	 DIARESIS_UPPER
   DW	 ALL_KB
   DB	 249,0
   DW	 CP850_DI_UP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 2
   DB	 18,0D3H		       ;; E
   DB	 23,0D8H		       ;; I
CP850_DI_UP_T_END:
   DW	 0
CP850_DI_UP_END:

   DW	 CP850_GR_UP_END-$
   DB	 GRAVE_UPPER
   DW	 ALL_KB
   DB	 96,0
   DW	 CP850_GR_UP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 5
   DB	 16,0B7H		       ;; A
   DB	 18,0D4H		       ;; E
   DB	 23,0DEH		       ;; I
   DB	 24,0E3H		       ;; O
   DB	 22,0EBH		       ;; U
CP850_GR_UP_T_END:
   DW	 0
CP850_GR_UP_END:

   DW	 CP850_TI_LO_END-$
   DB	 TILDE_LOWER
   DW	 ALL_KB
   DB	 126,0
   DW	 CP850_TI_LO_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 2
   DB	 16,0C6H		       ;; a
   DB	 24,0E4H		       ;; o
CP850_TI_LO_T_END:
   DW	 0
CP850_TI_LO_END:

   DW	 CP850_TI_UP_END-$
   DB	 TILDE_UPPER
   DW	 ALL_KB
   DB	 126,0
   DW	 CP850_TI_UP_T_END-$
   DB	 STANDARD_TABLE+ZERO_SCAN
   DB	 2
   DB	 16,0C7H		       ;; A
   DB	 24,0E5H		       ;; O
CP850_TI_UP_T_END:
   DW	 0
CP850_TI_UP_END:

   DW	 0			       ;; dernier etat
CP850_XLAT_END:

;;***************************************************************************
;; Fin de fichier
;;***************************************************************************
   DB	 'FRMAC - AZERTY Mac, derive de MS-DOS 4.0 (MIT)',0Dh,0Ah
   DB	 1AH

CODE	ENDS
	END	FILE_START	       ;; point d'entree a 100h exige par TLINK /t
