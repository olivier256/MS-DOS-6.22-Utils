/*
 * TEST.C - Banc d'essai de ED (TEST.EXE), a lancer sous DOS,
 *          de preference sur un disque virtuel en memoire.
 *
 * Il utilise les vrais modules BUF.C, LAY.C et FIO.C (vraie EMS, vrai
 * Turbo C, vrais appels DOS). Deux sortes d'essais :
 *
 * A. Cycles d'edition (a chaque cycle) :
 *    1. editions aleatoires (insertions, suppressions, copier, coller)
 *       appliquees au texte ET a une copie de reference independante,
 *       en memoire conventionnelle (jusqu'a 192 Ko, soit une douzaine
 *       de blocs : les coupures et recollages de blocs sont exerces) ;
 *       comparaison reguliere, plus controle interne de la table ;
 *    2. enregistrement, relecture brute du fichier (CR+LF compris) ;
 *    3. NOM.BAK : son empreinte doit etre celle de la version precedente ;
 *       sauvegarde automatique : NOM.SAV juste, NOM et NOM.BAK intacts ;
 *    4. rechargement et nouvelle comparaison.
 *
 * B. Gros fichier (au 1er cycle puis tous les 100 cycles, si l'EMS
 *    est presente) : fichier genere de la taille demandee, charge,
 *    controle, copie integrale collee au milieu, controle, suppression
 *    de la copie, controle, enregistrement et relecture brute.
 *    Le disque doit pouvoir contenir environ 3 fois cette taille,
 *    et le texte ne peut pas depasser 8 Mo (copie comprise) : 3 Mo au plus.
 *
 * Usage   : TESTBIG [cycles] [repertoire] [graine] [Ko du gros fichier]
 * Exemple : TESTBIG 2000 D:\ 0 1024        (graine 0 = tiree de l'heure)
 *
 * En cas d'echec : message, graine (pour rejouer), fichiers laisses sur
 * place, ERRORLEVEL 1. L'EMS est liberee dans tous les cas.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <dos.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#ifdef __TURBOC__
#include <mem.h>
#endif
#include "ed.h"

unsigned _stklen = 4096;

#define REFMAXP 12288u                  /* 192 Ko au plus par reference */

static unsigned long seed, seed0, gseed;
static unsigned long cycle, op;
static unsigned rseg = 0, cseg = 0;     /* reference, presse-papiers */
static pos_t rlen = 0, clen = 0, refmax = 0;
static int ems = 0, haveprev = 0;
static unsigned long prevhash = 0;
static pos_t prevlen = 0, peak = 0;
static unsigned long nfull = 0, nbig = 0;
static char fname[90], bname[90], sname[90], gname[90], gbname[90];
static unsigned char tmpb[512];
static char gen[400];
static unsigned char rdb[1024];

/* Adresse normalisee d'un octet d'un grand bloc DOS */
#define FARL(seg, i) ((unsigned char far *)MK_FP((seg) + (unsigned)((i) >> 4), \
                                                 (unsigned)((i) & 15)))

/* -------------------------------------------------------- utilitaires */

static unsigned rnd(unsigned n)
{
    seed = seed * 1103515245UL + 12345UL;
    return n ? (unsigned)((seed >> 16) % n) : 0;
}

static void fmv(unsigned char far *d, unsigned char far *s, unsigned n)
{
#ifdef __TURBOC__
    movedata(FP_SEG(s), FP_OFF(s), FP_SEG(d), FP_OFF(d), n);
#else
    while (n--) *d++ = *s++;
#endif
}

/* Copie entre deux grands blocs DOS distincts */
static void fcopyl(unsigned dseg, pos_t dpos, unsigned sseg, pos_t spos, pos_t n)
{
    unsigned k;

    while (n > 0) {
        k = n > 0x8000L ? 0x8000u : (unsigned)n;
        fmv(FARL(dseg, dpos), FARL(sseg, spos), k);
        dpos += k; spos += k; n -= k;
    }
}

static void cleanup(void)
{
    buf_done();                         /* libere l'EMS */
    if (rseg) freemem(rseg);
    if (cseg) freemem(cseg);
    rseg = cseg = 0;
}

static void fail(char *what, long a, long b)
{
    printf("\n\nECHEC au cycle %lu, operation %lu : %s (%ld, %ld)\n",
           cycle, op, what, a, b);
    printf("Graine : %lu   (rejouer : TESTBIG <cycles> <repertoire> %lu)\n",
           seed0, seed0);
    printf("Fichiers laisses pour examen : %s, %s, %s\n", fname, bname, gname);
    cleanup();
    exit(1);
}

static int on_break(void)
{
    cleanup();
    return 0;                           /* abandon du programme */
}

static unsigned char gen_byte(unsigned long *s)
{
    static unsigned char acc[] = { 0x82, 0x85, 0x8A, 0x87, 0x88, 0x8B,
                                   0x93, 0x97, 0x90, 0xB7, 0x96, 0x83 };
    unsigned k, c;

    *s = *s * 1103515245UL + 12345UL;
    k = (unsigned)((*s >> 16) % 100);
    *s = *s * 1103515245UL + 12345UL;
    c = (unsigned)((*s >> 16) & 0xFF);
    if (k < 58) return (unsigned char)('a' + c % 26);
    if (k < 73) return ' ';
    if (k < 78) return '\n';
    if (k < 81) return '\t';
    if (k < 90) return acc[c % sizeof acc];
    if (c == '\r' || c == 0x1A) c = 'X';    /* tout octet sauf CR et Ctrl+Z */
    return (unsigned char)c;
}

/* --------------------------------------------- reference independante */

static void ref_up(pos_t p, pos_t n)    /* [p, rlen) remonte de n */
{
    pos_t end = rlen;
    unsigned k;

    while (end > p) {
        k = (end - p > (pos_t)sizeof tmpb) ? sizeof tmpb : (unsigned)(end - p);
        end -= k;
        fmv((unsigned char far *)tmpb, FARL(rseg, end), k);
        fmv(FARL(rseg, end + n), (unsigned char far *)tmpb, k);
    }
    rlen += n;
}

static void ref_down(pos_t p, pos_t n)  /* [p + n, rlen) descend de n */
{
    pos_t s = p + n;
    unsigned k;

    while (s < rlen) {
        k = (rlen - s > (pos_t)sizeof tmpb) ? sizeof tmpb : (unsigned)(rlen - s);
        fmv((unsigned char far *)tmpb, FARL(rseg, s), k);
        fmv(FARL(rseg, s - n), (unsigned char far *)tmpb, k);
        s += k;
    }
    rlen -= n;
}

static void check_table(char *where)
{
    int r = buf_check();

    if (r) fail(where, r, BLEN());
}

static void check_buffer(char *where)
{
    pos_t p = 0, L = BLEN();
    unsigned n, i;
    unsigned char far *s;

    if (L != rlen) fail(where, L, rlen);
    while (p < L) {
        s = buf_span(p, &n);
        if (n == 0) fail("tranche vide", p, L);
        for (i = 0; i < n; i++)
            if (s[i] != *FARL(rseg, p + i))
                fail(where, p + i, s[i]);
        p += n;
    }
    if (buf_cliplen() != clen) fail("longueur du presse-papiers", buf_cliplen(), clen);
    check_table("table des blocs incoherente");
}

/* Empreinte FNV-1a */
#define HSTEP(h, c) ((h) = ((h) ^ (unsigned char)(c)) * 16777619UL)

/* Empreinte de la reference telle qu'enregistree (CR+LF) */
static unsigned long ref_hash(void)
{
    unsigned long h = 2166136261UL;
    pos_t i;
    unsigned char c;

    for (i = 0; i < rlen; i++) {
        c = *FARL(rseg, i);
        if (c == '\n') HSTEP(h, '\r');
        HSTEP(h, c);
    }
    return h;
}

static unsigned long file_hash(char *path, pos_t *len)
{
    unsigned long h = 2166136261UL;
    int fd, n, i;

    *len = 0;
    fd = open(path, O_RDONLY | O_BINARY);
    if (fd < 0) return 0;
    while ((n = read(fd, rdb, sizeof rdb)) > 0)
        for (i = 0; i < n; i++) {
            HSTEP(h, rdb[i]);
            (*len)++;
        }
    close(fd);
    return h;
}

/* Le fichier contient-il exactement la reference, avec CR+LF ? */
static void check_file(char *path, char *what)
{
    int fd, n, i, lf = 0;
    pos_t p = 0;
    unsigned char c;
    long off = 0;

    fd = open(path, O_RDONLY | O_BINARY);
    if (fd < 0) fail(what, 0, 0);
    while ((n = read(fd, rdb, sizeof rdb)) > 0) {
        for (i = 0; i < n; i++, off++) {
            if (lf) {
                c = '\n';
                lf = 0;
            } else {
                if (p >= rlen) { close(fd); fail(what, off, 1); }
                c = *FARL(rseg, p);
                p++;
                if (c == '\n') { c = '\r'; lf = 1; }
            }
            if (rdb[i] != c) { close(fd); fail(what, off, rdb[i]); }
        }
    }
    close(fd);
    if (n < 0 || lf || p != rlen) fail(what, off, 2);
}

static void check_misc(void)
{
    pos_t a, b, i, k = 0, f, r, e, q;
    int j;

    a = rnd((unsigned)(rlen / 4 + 1)) * 4L;
    if (a > rlen) a = rlen;
    b = a + rnd(40000);
    if (b > rlen) b = rlen;
    for (i = a; i < b; i++) if (*FARL(rseg, i) == '\n') k++;
    if (buf_count(a, b, '\n') != k) fail("buf_count", a, b);

    f = NOPOS;
    for (i = a; i < rlen; i++) if (*FARL(rseg, i) == '\t') { f = i; break; }
    if (buf_find(a, '\t') != f) fail("buf_find", a, f);

    f = NOPOS;
    for (i = b; i > 0; i--) if (*FARL(rseg, i - 1) == '\n') { f = i - 1; break; }
    if (buf_rfind(b, '\n') != f) fail("buf_rfind", b, f);

    for (j = 0; j < 10; j++) {
        a = (pos_t)rnd((unsigned)(rlen / 8 + 1)) * 8;
        if (a > rlen) a = rlen;
        r = row_start(a);
        e = lay_row(r, (cell_t *)0, 0);
        if (!(r <= a && a < e)) fail("rangee", a, r);
        if (r > 0) {
            q = row_start(r - 1);
            if (lay_row(q, (cell_t *)0, 0) != r) fail("chainage des rangees", q, r);
        }
    }
}

/* ---------------------------------------------------------- editions */

static pos_t rpos(void)
{
    pos_t p = ((pos_t)rnd(0x8000u) << 15 | rnd(0x8000u)) % (rlen + 1);
    return p;
}

static void edit_once(void)
{
    unsigned k = rnd(100), n, i;
    pos_t p = rpos(), a, b, m, done;

    op++;
    if (k < 40) {                               /* insertion d'une suite */
        n = 1 + rnd(sizeof gen);
        if (rlen + n > refmax) return;
        if (rnd(10) == 0)
            for (i = 0; i < n; i++) gen[i] = 'W';
        else
            for (i = 0; i < n; i++) gen[i] = (char)gen_byte(&seed);
        if (buf_ins(p, gen, n)) {
            ref_up(p, n);
            fmv(FARL(rseg, p), (unsigned char far *)gen, n);
        } else
            nfull++;                    /* memoire pleine : rien ne doit changer */
    } else if (k < 55) {                        /* un caractere */
        if (rlen + 1 > refmax) return;
        gen[0] = (char)gen_byte(&seed);
        if (buf_insch(p, (unsigned char)gen[0])) {
            ref_up(p, 1);
            *FARL(rseg, p) = (unsigned char)gen[0];
        } else
            nfull++;
    } else if (k < 80) {                        /* suppression */
        m = rnd(rnd(40) == 0 ? 60000u : 300);
        if (m > rlen - p) m = rlen - p;
        buf_del(p, m);
        ref_down(p, m);
    } else if (k < 90) {                        /* copier */
        a = p;
        b = a + rnd(rnd(4) == 0 ? 50000u : 3000);
        if (b > rlen) b = rlen;
        if (b > a) {
            if (buf_setclip(a, b)) {
                fcopyl(cseg, 0, rseg, a, b - a);
                clen = b - a;
            } else {
                clen = buf_cliplen();   /* echec : presse-papiers vide */
                nfull++;
            }
        }
    } else {                                    /* coller */
        if (clen && rlen + clen <= refmax) {
            done = buf_paste(p);        /* moins si memoire pleine */
            if (done) {
                ref_up(p, done);
                fcopyl(rseg, p, cseg, 0, done);
            }
            if (done < clen) nfull++;
        }
    }
}

/* ------------------------------------------------------ gros fichier */

/* Compare le texte a la suite generee (graine s), decalages a la fin */
static void big_check(unsigned long s, pos_t len, pos_t mid, pos_t dup)
{
    pos_t i;
    unsigned char a;

    /* dup = 0 : texte = A ; dup = len : texte = A[0..mid) A A[mid..len) */
    if (BLEN() != len + dup) fail("gros fichier : longueur", BLEN(), len + dup);
    for (i = 0; i < len; i++) {
        a = gen_byte(&s);
        if (dup) {
            if (buf_at(mid + i) != a) fail("gros fichier : copie collee", mid + i, a);
            if (i < mid) { if (buf_at(i) != a) fail("gros fichier : debut", i, a); }
            else if (buf_at(len + i) != a) fail("gros fichier : fin", len + i, a);
        } else if (buf_at(i) != a)
            fail("gros fichier : contenu", i, a);
    }
    check_table("gros fichier : table incoherente");
}

static void big_file_check(char *path, unsigned long s, pos_t len, char *what)
{
    int fd, n, i, lf = 0;
    pos_t p = 0;
    unsigned char c;

    fd = open(path, O_RDONLY | O_BINARY);
    if (fd < 0) fail(what, 0, 0);
    while ((n = read(fd, rdb, sizeof rdb)) > 0)
        for (i = 0; i < n; i++) {
            if (lf) { c = '\n'; lf = 0; }
            else {
                if (p >= len) { close(fd); fail(what, p, 1); }
                c = gen_byte(&s);
                p++;
                if (c == '\n') { c = '\r'; lf = 1; }
            }
            if (rdb[i] != c) { close(fd); fail(what, p, rdb[i]); }
        }
    close(fd);
    if (lf || p != len) fail(what, p, 2);
}

static void big_test(pos_t len)
{
    unsigned long s;
    pos_t i, mid;
    int fd, k, r;
    unsigned char c;

    if (!ems || len <= 0) return;
    gseed = seed0 ^ (cycle * 2654435761UL);
    remove(gname);
    remove(gbname);
    fd = open(gname, O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, S_IREAD | S_IWRITE);
    if (fd < 0) fail("gros fichier : creation", 0, 0);
    s = gseed;
    k = 0;
    for (i = 0; i < len; i++) {
        c = gen_byte(&s);
        if (c == '\n') rdb[k++] = '\r';
        rdb[k++] = c;
        if (k >= (int)sizeof rdb - 1) {
            if (write(fd, rdb, k) != k) fail("gros fichier : disque plein ?", i, 0);
            k = 0;
        }
    }
    if (k && write(fd, rdb, k) != k) fail("gros fichier : disque plein ?", i, 0);
    close(fd);

    printf("\rCycle %lu : gros fichier de %ld Ko...                          ",
           cycle, len >> 10);
    r = fio_load(gname);
    if (r != FIO_OK) fail("gros fichier : chargement", r, len);
    big_check(gseed, len, 0, 0);

    mid = len / 3;                              /* tout copier, coller au tiers */
    if (!buf_setclip(0, len)) fail("gros fichier : copie integrale", 0, len);
    if (buf_paste(mid) != len) fail("gros fichier : collage integral", mid, len);
    big_check(gseed, len, mid, len);
    buf_del(mid, len);                          /* et retirer la copie */
    big_check(gseed, len, 0, 0);

    r = fio_save(gname);
    if (r != FIO_OK) fail("gros fichier : enregistrement", r, len);
    big_file_check(gname, gseed, len, "gros fichier enregistre incorrect");
    big_file_check(gbname, gseed, len, "gros fichier : .BAK incorrect");

    remove(gname);
    remove(gbname);
    r = fio_load(fname);                        /* retour au texte du test A */
    if (r != FIO_OK) fail("rechargement apres gros fichier", r, rlen);
    buf_setclip(0, 0);                          /* presse-papiers vide */
    clen = 0;
    nbig++;
}

/* ---------------------------------------------------------------- main */

static void mkname(char *dst, char *dir, char *base)
{
    int l;

    strcpy(dst, dir);
    l = strlen(dst);
    if (l && dst[l - 1] != '\\' && dst[l - 1] != ':') strcat(dst, "\\");
    strcat(dst, base);
}

int main(int argc, char *argv[])
{
    unsigned long cycles = 200, nops, written = 0;
    unsigned seg, avail, paras;
    pos_t biglen = 1024L * 1024L, flen, blen0;
    unsigned long bhash;
    char *dir = "";
    int r;
    time_t t0;

    if (argc > 1) cycles = atol(argv[1]);
    if (argc > 2) dir = argv[2];
    seed = (argc > 3) ? (unsigned long)atol(argv[3]) : 0;
    if (seed == 0) seed = (unsigned long)time(NULL);
    if (argc > 4) biglen = atol(argv[4]) * 1024L;
    seed0 = seed;

    mkname(fname, dir, "EDWTEST.TXT");
    mkname(bname, dir, "EDWTEST.BAK");
    mkname(sname, dir, "EDWTEST.SAV");
    mkname(gname, dir, "EDWBIG.TXT");
    mkname(gbname, dir, "EDWBIG.BAK");

    buf_init();
    ctrlbrk(on_break);
    ems = strcmp(buf_where, "EMS") == 0;
    r = allocmem(0xFFFF, &seg);                 /* plus gros bloc libre */
    avail = (r == -1) ? 0xFFFF : (unsigned)r;
    if (r == -1) freemem(seg);
    paras = avail / (ems ? 3 : 6);
    if (paras > REFMAXP) paras = REFMAXP;
    if (paras < 1024) { cleanup(); puts("Memoire conventionnelle insuffisante."); return 1; }
    if (allocmem(paras, &seg) != -1) { cleanup(); puts("Memoire insuffisante."); return 1; }
    rseg = seg;
    if (allocmem(paras, &seg) != -1) { cleanup(); puts("Memoire insuffisante."); return 1; }
    cseg = seg;
    refmax = (pos_t)paras * 16 - 16;
    lay_w = LAYW;

    printf("Banc d'essai ED : %lu cycles, texte en %s, reference %ld Ko\n",
           cycles, buf_where, refmax >> 10);
    if (ems)
        printf("Gros fichier : %ld Ko au 1er cycle puis tous les 100 cycles\n",
               biglen >> 10);
    else
        printf("Pas d'EMS : pas d'essai de gros fichier\n");
    printf("Fichiers : %s   Graine : %lu\n\n", fname, seed0);
    remove(fname);
    remove(bname);
    t0 = time(NULL);

    for (cycle = 1; cycle <= cycles; cycle++) {
        if (cycle % 25 == 1) {                  /* repartir de presque rien */
            buf_reset();
            rlen = 0;
        }
        nops = 1 + rnd(400);
        while (nops--) {
            edit_once();
            if (op % 64 == 0) check_buffer("texte different de la reference");
            if (op % 97 == 0) check_misc();
        }
        check_buffer("texte different de la reference");
        if (rlen > peak) peak = rlen;

        r = fio_save(fname);
        if (r != FIO_OK) fail("fio_save", r, rlen);
        written += rlen;
        check_file(fname, "fichier enregistre incorrect");
        if (haveprev) {
            if (file_hash(bname, &flen) != prevhash || flen != prevlen)
                fail("NOM.BAK incorrect", flen, prevlen);
        }
        prevhash = ref_hash();
        prevlen = rlen + buf_count(0, BLEN(), '\n');
        haveprev = 1;

        bhash = file_hash(bname, &blen0);       /* sauvegarde automatique */
        r = fio_autosave(fname);
        if (r != FIO_OK) fail("fio_autosave", r, rlen);
        check_file(sname, "NOM.SAV incorrect");
        check_file(fname, "NOM modifie par la sauvegarde automatique");
        if (file_hash(bname, &flen) != bhash || flen != blen0)
            fail("NOM.BAK modifie par la sauvegarde automatique", flen, blen0);
        fio_unsav(fname);
        if (fio_hassav(fname)) fail("NOM.SAV non supprime", 0, 0);

        r = fio_load(fname);
        if (r != FIO_OK) fail("fio_load", r, rlen);
        check_buffer("texte recharge different de la reference");

        if (cycle == 1 || cycle % 100 == 0) {
            big_test(biglen);
            check_buffer("texte different apres le gros fichier");
        }

        printf("\rCycle %lu/%lu   operations %lu   taille %6ld   ecrit %lu Ko     ",
               cycle, cycles, op, rlen, written >> 10);
    }

    printf("\n\nOK : %lu cycles, %lu operations, %lu Ko ecrits et relus, "
           "%lu s, aucune erreur.\n", cycles, op, written >> 10,
           (unsigned long)(time(NULL) - t0));
    printf("Taille maximale (test A) : %ld octets ; gros fichiers verifies : %lu ; "
           "operations refusees (memoire pleine) : %lu\n", peak, nbig, nfull);
    if (nfull && ems)
        printf("(avec l'EMS, ce nombre devrait etre 0 sauf memoire EMS presque epuisee)\n");
    remove(fname);
    remove(bname);
    cleanup();
    return 0;
}
