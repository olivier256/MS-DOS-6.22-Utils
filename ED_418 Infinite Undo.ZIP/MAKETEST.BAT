@echo off
rem Banc d'essai de ED (Turbo C 2.0, modele small) : voir MAKEFILE.
rem Usage ensuite : TEST [cycles] [repertoire] [graine] [Ko du gros fichier]
rem par exemple   : TEST 2000 D:\ 0 1024
rem
rem Prevoir au moins trois fois plus de EMS que la taille du fichier
rem
if not exist OBJ\nul md OBJ
make.exe TEST.EXE
