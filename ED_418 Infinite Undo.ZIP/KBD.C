/*
 * KBD.C - Clavier par le BIOS (INT 16h) et table des raccourcis
 *
 * Sur un clavier etendu (bit 4 de 0040:0096), on utilise les
 * fonctions 10h/12h, qui rendent aussi Ctrl+Haut/Bas et Ctrl+Suppr.
 * KEYB s'occupe de la disposition (AZERTY, accents) : on recoit
 * deja les bons codes ASCII.
 *
 * Pour changer un raccourci, il suffit de modifier la table kmap.
 */

#include <dos.h>
#include "ed.h"

static int kbd_enh = 0;

static void kbd_detect_win(void);

void kbd_init(void)
{
    kbd_enh = (*(unsigned char far *)MK_FP(0x40, 0x96) & 0x10) != 0;
    kbd_detect_win();
}

/* Une touche attend-elle ? (tete != queue du tampon BIOS) */
int kbd_pending(void)
{
    return *(unsigned short far *)MK_FP(0x40, 0x1A) !=
           *(unsigned short far *)MK_FP(0x40, 0x1C);
}

/* Compteur d'horloge du BIOS : 18,2 tops par seconde, remis a 0 a minuit */
unsigned long kbd_ticks(void)
{
    unsigned short far *t = (unsigned short far *)MK_FP(0x40, 0x6C);
    unsigned lo, hi;

    do {                                /* le compteur peut avancer entre */
        hi = t[1];                      /* les deux lectures */
        lo = t[0];
    } while (hi != t[1]);
    return ((unsigned long)hi << 16) | lo;
}

/*
 * Attente du clavier sans boucle de scrutation.
 *
 * kbd_idle() suspend le processeur (HLT) jusqu'a la prochaine
 * interruption materielle : touche (IRQ 1) ou horloge (IRQ 0, 18,2 fois
 * par seconde). L'horloge suffit pour la sauvegarde automatique, qui se
 * compte en secondes. Dans une VM, le processeur virtuel dort vraiment :
 * l'hote ne voit plus qu'une vingtaine de reveils par seconde.
 *
 * Le test "tampon vide ?" et le HLT se font interruptions masquees
 * (CLI ... STI ; HLT) : une touche arrivee juste apres le test ne peut
 * pas etre servie avant le HLT, puisque STI ne prend effet qu'apres
 * l'instruction suivante. Sinon on dormirait jusqu'au top d'horloge
 * suivant (55 ms) avec une touche en attente.
 *
 * Turbo C 2.0 n'a pas d'assembleur en ligne sans TASM : le code est
 * une petite routine en octets, appelee en far dans le segment de
 * donnees (mode reel : pas de protection en execution).
 *
 * Sous Windows 386 enhanced (session DOS), on utilise d'abord
 * INT 2Fh 1680h, qui rend la main aux autres taches. Sous EMM386
 * (mode V86), HLT est une instruction privilegiee : elle passe par
 * le gestionnaire d'EMM386 (a verifier si EMM386 est charge).
 */
static unsigned char hlt_code[] = {
    0xFA,                   /* cli                              */
    0x1E,                   /* push ds                          */
    0xB8, 0x40, 0x00,       /* mov  ax, 40h                     */
    0x8E, 0xD8,             /* mov  ds, ax                      */
    0xA1, 0x1A, 0x00,       /* mov  ax, [1Ah]   tete du tampon  */
    0x3B, 0x06, 0x1C, 0x00, /* cmp  ax, [1Ch]   queue           */
    0x1F,                   /* pop  ds                          */
    0x75, 0x03,             /* jne  touche                      */
    0xFB,                   /* sti                              */
    0xF4,                   /* hlt  (reveil a l'interruption)   */
    0xCB,                   /* retf                             */
    0xFB,                   /* touche: sti                      */
    0xCB                    /* retf                             */
};

static int kbd_win = 0;     /* Windows 386 enhanced detecte */

static void kbd_detect_win(void)
{
    union REGS r;

    r.x.ax = 0x1600;
    int86(0x2F, &r, &r);
    kbd_win = r.h.al != 0x00 && r.h.al != 0x80;
}

void kbd_idle(void)
{
    union REGS r;
    void (far *halt)(void);

    if (kbd_win) {
        r.x.ax = 0x1680;                /* rendre la tranche de temps */
        int86(0x2F, &r, &r);
        if (r.h.al == 0x00)
            return;
    }
    halt = (void (far *)(void))MK_FP(_DS, (unsigned)hlt_code);
    halt();
}

int kbd_get(int *shift)
{
    union REGS r;
    int asc, scan;

    r.h.ah = kbd_enh ? 0x10 : 0x00;
    int86(0x16, &r, &r);
    asc = r.h.al;
    scan = r.h.ah;

    r.h.ah = kbd_enh ? 0x12 : 0x02;
    int86(0x16, &r, &r);
    *shift = (r.h.al & 0x03) != 0;

    if ((asc == 0 || asc == 0xE0) && scan != 0)
        return KX(scan);
    return asc;
}

struct kmap {
    int code;
    int cmd;
};

static struct kmap kmap[] = {
    { K_LEFT,    C_LEFT    },
    { K_RIGHT,   C_RIGHT   },
    { K_UP,      C_UP      },
    { K_DOWN,    C_DOWN    },
    { K_HOME,    C_HOME    },
    { K_END,     C_END     },
    { K_PGUP,    C_PGUP    },
    { K_PGDN,    C_PGDN    },
    { K_CHOME,   C_TOP     },
    { K_CEND,    C_BOTTOM  },
    { K_CPGUP,   C_TOP     },
    { K_CPGDN,   C_BOTTOM  },
    { K_CLEFT,   C_WLEFT   },
    { K_CRIGHT,  C_WRIGHT  },
    { K_CUP,     C_PARUP   },
    { K_CDOWN,   C_PARDOWN },
    { K_BKSP,    C_BKSP    },
    { K_DEL,     C_DEL     },
    { K_CBKSP,   C_WBKSP   },
    { K_CDEL,    C_WDEL    },
    { K_ENTER,   C_ENTER   },
    { 10,        C_ENTER   },       /* Ctrl+Entree */
    { K_TAB,     C_TAB     },
    { K_INS,     C_INS     },
    { K_ESC,     C_ESC     },
    { CTRL('A'), C_SELALL  },
    { CTRL('C'), C_COPY    },
    { CTRL('X'), C_CUT     },
    { CTRL('V'), C_PASTE   },
    { CTRL('F'), C_FIND    },
    { CTRL('G'), C_FINDNEXT},
    { CTRL('S'), C_SAVE    },       /* Maj+Ctrl+S : enregistrer sous */
    { CTRL('O'), C_OPEN    },
    { CTRL('N'), C_NEW     },
    { CTRL('Q'), C_QUIT    },
    { CTRL('Z'), C_UNDO    },       /* Maj+Ctrl+Z : refaire */
    { CTRL('Y'), C_REDO    },
    { CTRL('P'), C_ABOUT   },       /* Ctrl+P (Ctrl+F1 n'arrive pas dans la VM) */
    /*
     * Raccourcis facon Mac a ajouter plus tard, par exemple si
     * l'hote envoie Alt pour Cmd : { KX(0x2E), C_COPY } (Alt+C), etc.
     */
    { 0, 0 }
};

int key_cmd(int code)
{
    struct kmap *k;

    for (k = kmap; k->code; k++)
        if (k->code == code)
            return k->cmd;
    return C_NONE;
}
