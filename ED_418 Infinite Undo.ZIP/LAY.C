/*
 * LAY.C - Decoupage du texte en rangees d'ecran (retour a la ligne)
 *
 * Le texte est un flux d'octets ; '\n' separe les paragraphes.
 * Une rangee commence a une position s et s'arrete :
 *   - apres un '\n' (fin de paragraphe) ;
 *   - sinon, quand le caractere suivant ne tient plus dans lay_w
 *     colonnes : on coupe juste apres le dernier espace de la rangee ;
 *     si ce caractere est lui-meme un espace, il reste en bout de
 *     rangee ; s'il n'y a aucun espace, on coupe net.
 * La fin du texte se comporte comme un '\n' virtuel en position L :
 * la derniere rangee renvoie L + 1.
 *
 * lay_row() sert a la fois a l'affichage (out != NULL) et aux
 * deplacements (out == NULL) : les deux suivent donc la meme regle.
 */

#include "ed.h"

int  lay_w = LAYW;          /* largeur de coupure */
int  lay_tab = 8;           /* taquets de tabulation */
pos_t lay_cur = NOPOS;      /* position du curseur a reperer */
pos_t lay_sa = 0, lay_sb = 0; /* selection [lay_sa, lay_sb) */
int  lay_curcol = -1;       /* colonne du curseur si dans la rangee */

#define CELL(a, c)  ((cell_t)(((a) << 8) | (c)))

pos_t lay_row(pos_t s, cell_t *out, int ncols)
{
    unsigned char far *p = 0;
    unsigned n = 0;
    pos_t pos = s, L = BLEN(), last = NOPOS, e;
    int col = 0, lastcol = 0, fill, w, c, cc = -1, i, a;

    for (;;) {
        if (pos == lay_cur) cc = col;
        if (pos >= L) {                 /* fin du texte */
            e = L + 1;
            fill = col;
            break;
        }
        if (n == 0) p = buf_span(pos, &n);
        c = *p++;
        n--;
        a = (pos >= lay_sa && pos < lay_sb) ? A_SEL : A_TEXT;

        if (c == '\n') {
            fill = col;
            if (out && a == A_SEL && col < ncols) {
                out[col] = CELL(A_SEL, ' ');
                fill = col + 1;
            }
            e = pos + 1;
            break;
        }

        w = (c == '\t') ? lay_tab - col % lay_tab : 1;
        if (col + w > lay_w) {          /* ne tient plus */
            if (c == ' ' || c == '\t') {
                fill = col;
                if (out && col < ncols) {
                    out[col] = CELL(a, ' ');
                    fill = col + 1;
                }
                e = pos + 1;
            } else if (last != NOPOS && last > s) {
                e = last;
                fill = lastcol;
            } else if (pos == s) {      /* cas degenere : avancer quand meme */
                e = pos + 1;
                fill = col;
            } else {
                e = pos;                /* mot plus long que la rangee */
                fill = col;
            }
            break;
        }

        if (out) {
            if (c == '\t') {
                for (i = 0; i < w && col + i < ncols; i++)
                    out[col + i] = CELL(a, ' ');
            } else if (col < ncols)
                out[col] = CELL(a, c);
        }
        col += w;
        if (c == ' ' || c == '\t') {
            last = pos + 1;
            lastcol = col;
        }
        pos++;
    }

    if (out)
        for (i = fill; i < ncols; i++)
            out[i] = CELL(A_TEXT, ' ');
    if (cc >= 0 && lay_cur >= s && lay_cur < e)
        lay_curcol = cc;
    return e;
}

/* Debut de la rangee qui contient la position p */
pos_t row_start(pos_t p)
{
    pos_t r, e;

    r = buf_rfind(p, '\n');            /* debut du paragraphe */
    r = (r == NOPOS) ? 0 : r + 1;
    for (;;) {
        e = lay_row(r, (cell_t *)0, 0);
        if (p < e) return r;
        r = e;
    }
}

/* Colonne d'affichage de p dans la rangee qui commence en r */
int col_of(pos_t r, pos_t p)
{
    pos_t save = lay_cur;
    int c;

    lay_cur = p;
    lay_curcol = -1;
    lay_row(r, (cell_t *)0, 0);
    c = lay_curcol;
    lay_cur = save;
    return c < 0 ? 0 : c;
}

/* Position de la rangee r la plus proche de la colonne goal */
pos_t pos_at_col(pos_t r, int goal)
{
    pos_t e, L = BLEN(), last, pos;
    int col = 0, c, w;

    e = lay_row(r, (cell_t *)0, 0);
    last = (e > L) ? L : e - 1;
    for (pos = r; pos < last; pos++) {
        c = buf_at(pos);
        w = (c == '\t') ? lay_tab - col % lay_tab : 1;
        if (col + w > goal) break;
        col += w;
    }
    return pos;
}
