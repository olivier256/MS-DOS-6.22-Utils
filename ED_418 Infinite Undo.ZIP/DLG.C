/*
 * DLG.C - Boite de dialogue modale en mode texte
 *
 * dlg_box() dessine une boite au milieu de l'ecran (par-dessus l'image
 * en cours de scr_sh, avec une ombre), attend un choix et rend l'indice
 * du bouton. Elle ne connait rien de l'editeur : elle n'utilise que
 * SCR.C pour dessiner et KBD.C pour lire les touches. L'appelant doit
 * redessiner l'ecran apres coup.
 *
 *   title : titre, sur la bordure haute
 *   text  : lignes de texte separees par '\n' (8 lignes au plus)
 *   btn   : libelles des boutons ; la premiere lettre sert de raccourci
 *   def   : bouton choisi au depart
 *   esc   : indice rendu par Echap
 *
 * Touches : Entree ou Espace valident le bouton choisi ; Tab, Droite et
 * Bas passent au suivant, Maj+Tab, Gauche et Haut au precedent ; la
 * premiere lettre d'un bouton le valide d'un coup (sauf s'il n'y a
 * qu'un bouton : seuls Entree, Espace et Echap comptent alors).
 *
 * Le tampon clavier est vide a l'ouverture : des touches frappees
 * pendant que la boite apparait ne doivent pas repondre a sa place.
 */

#include <string.h>
#include <ctype.h>
#include "ed.h"

#define MAXLIN  8
#define MAXBTN  4

int dlg_box(char *title, char *text, char *btn[], int nbtn, int def, int esc)
{
    char *line[MAXLIN], *p, t[SCOLS + 1], s[40];
    int len[MAXLIN], bx[MAXBTN];
    int nl = 0, i, k, sh, w, h, r0, c0, r, c, rb, tl, ta, bw, mw = 0, sel = def;

    while (kbd_pending())
        kbd_get(&sh);

    p = text;                           /* decoupage du texte en lignes */
    for (;;) {
        line[nl] = p;
        len[nl] = 0;
        while (*p && *p != '\n') {
            p++;
            len[nl]++;
        }
        if (len[nl] > mw) mw = len[nl];
        nl++;
        if (!*p || nl == MAXLIN) break;
        p++;
    }

    bw = 2 * (nbtn - 1);                /* largeur de la rangee de boutons */
    for (i = 0; i < nbtn; i++)
        bw += strlen(btn[i]) + 4;       /* "< libelle >" */
    tl = strlen(title);
    ta = strcmp(title, "Erreur") == 0 ? A_DERR : A_DTIT;
    w = mw > bw ? mw : bw;
    if (tl + 6 > w) w = tl + 6;
    w += 6;
    if (w > SCOLS - 4) w = SCOLS - 4;
    h = nl + 5;                         /* bordures, marges, boutons */
    r0 = (SROWS - h) / 2;
    c0 = (SCOLS - w) / 2;
    rb = r0 + h - 2;

    for (;;) {
        for (r = r0; r < r0 + h; r++)   /* fond et bordures */
            scr_fill(r, c0, w, ' ', A_DLG);
        scr_fill(r0, c0, w, 0xC4, A_DLG);
        scr_fill(r0 + h - 1, c0, w, 0xC4, A_DLG);
        for (r = r0 + 1; r < r0 + h - 1; r++) {
            scr_fill(r, c0, 1, 0xB3, A_DLG);
            scr_fill(r, c0 + w - 1, 1, 0xB3, A_DLG);
        }
        scr_fill(r0, c0, 1, 0xDA, A_DLG);
        scr_fill(r0, c0 + w - 1, 1, 0xBF, A_DLG);
        scr_fill(r0 + h - 1, c0, 1, 0xC0, A_DLG);
        scr_fill(r0 + h - 1, c0 + w - 1, 1, 0xD9, A_DLG);

        c = c0 + (w - tl - 2) / 2;      /* titre */
        scr_fill(r0, c, tl + 2, ' ', ta);
        scr_puts(r0, c + 1, title, ta);

        for (i = 0; i < nl; i++) {      /* texte */
            k = len[i] < w - 6 ? len[i] : w - 6;
            memcpy(t, line[i], k);
            t[k] = 0;
            scr_puts(r0 + 2 + i, c0 + 3, t, A_DLG);
        }

        c = c0 + (w - bw) / 2;          /* boutons */
        for (i = 0; i < nbtn; i++) {
            strcpy(s, "< ");
            strcat(s, btn[i]);
            strcat(s, " >");
            scr_puts(rb, c, s, i == sel ? A_DSEL : A_DLG);
            if (nbtn > 1)
                scr_fill(rb, c + 2, 1, btn[i][0], i == sel ? A_DHOTS : A_DHOT);
            bx[i] = c;
            c += strlen(s) + 2;
        }

        for (r = r0 + 1; r <= r0 + h; r++)      /* ombre */
            for (c = c0 + w; c < c0 + w + 2 && c < SCOLS; c++)
                if (r < SROWS)
                    scr_sh[r * SCOLS + c] =
                        (scr_sh[r * SCOLS + c] & 0x00FF) | ((cell_t)A_DSHAD << 8);
        if (r0 + h < SROWS)
            for (c = c0 + 2; c < c0 + w + 2 && c < SCOLS; c++)
                scr_sh[(r0 + h) * SCOLS + c] =
                    (scr_sh[(r0 + h) * SCOLS + c] & 0x00FF) | ((cell_t)A_DSHAD << 8);

        scr_cursor(rb, bx[sel] + 2);
        scr_flush();

        while (!kbd_pending())
            kbd_idle();
        k = kbd_get(&sh);
        if (k == K_ENTER || k == ' ')
            return sel;
        if (k == K_ESC)
            return esc;
        if (k == K_TAB || k == K_RIGHT || k == K_DOWN)
            sel = (sel + 1) % nbtn;
        else if (k == KX(0x0F) || k == K_LEFT || k == K_UP)
            sel = (sel + nbtn - 1) % nbtn;
        else if (nbtn > 1 && k > 32 && k < 256)
            for (i = 0; i < nbtn; i++)
                if (toupper(k) == toupper((unsigned char)btn[i][0]))
                    return i;
    }
}
