/*
 * ED.C - ED : editeur de texte pour MS-DOS avec retour automatique
 *         a la ligne, pour des fichiers de plusieurs Mo
 *
 * Limites : environ 500ko en m�moire conventionnelle,
 *           8Mo en m�moire pagin�e (HIMEM.SYS /NUMHANDLES=128)
 *           Prevoir environ trois fois la taille du texte en m�moire
 *
 * Compilation (Turbo C 2.0, modele small) : voir MAKE.BAT
 * Usage : ED [fichier]
 *
 * Boucle principale : on lit une touche, on l'execute, et on ne
 * redessine que s'il ne reste plus de touche en attente. Les
 * repetitions rapides ne s'accumulent donc jamais en retard.
 */

#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ed.h"

unsigned _heaplen = 1024;       /* tas proche : presque inutilise */
unsigned _stklen = 2048;

static pos_t cur = 0;           /* position du curseur */
static pos_t anchor = NOPOS;    /* autre bout de la selection */
static pos_t top = 0;           /* debut de la rangee en haut d'ecran */
static pos_t curpara = 1, npara = 1, clipnl = 0;
static int goal = -1;           /* colonne visee par Haut/Bas */
static int insmode = 1, dirty = 0, neednorm = 0, quit = 0;
static int asdirty = 0;          /* modifie depuis la derniere sauvegarde auto */
static unsigned long lastsave = 0, lastkey = 0;   /* tops d'horloge */

#define T_AUTO   1092L          /* 60 s : sauvegarde automatique... */
#define T_PAUSE  36L            /* ...apres 2 s sans frappe... */
#define T_FORCE  2184L          /* ...ou au bout de 120 s quoi qu'il arrive */
#define T_MSG    55L            /* 3 s : duree d'un message d'information */
static int trows;               /* rangees de texte */
static int crow = 0, ccol = 0;  /* curseur a l'ecran */
static char fname[81];
static char *msg = 0;           /* message de la ligne du bas, ou 0 */
static int msg_warn = 0;        /* avertissement (rouge) et non information */
static unsigned long msg_t = 0; /* top d'horloge de son affichage */
static int as_failed = 0;       /* sauvegarde auto en echec, boite deja montree */
static char findstr[64];
static pos_t rs[4 * SROWS + 1];

/*
 * Message dans la ligne du bas (la bordure du cadre, remplacee un
 * instant). Information : noir sur cyan, 3 s ou jusqu'a la touche
 * suivante. Avertissement : blanc sur rouge, jusqu'a la touche suivante.
 * Les erreurs a acquitter passent par err_box().
 */
static void say(char *s, int warn)
{
    msg = s;
    msg_warn = warn;
    msg_t = kbd_ticks();
}

static int on_break(void)
{
    return 1;                   /* ignorer Ctrl+Break */
}

/*
 * Erreur critique (disquette absente, disque protege...) : on repond
 * "Echec" a DOS, qui rend une erreur a open()/write(). Sans cela, DOS
 * proposerait "Abandonner", qui tuerait ED sans liberer l'EMS.
 */
static int on_crit(void)    /* les 4 parametres passes par harderr() sont ignores */
{
    hardresume(3);
    return 3;
}

/* ---------------------------------------------------------------- etat */

static int has_sel(void)  { return anchor != NOPOS && anchor != cur; }
static pos_t sel_a(void)  { return anchor < cur ? anchor : cur; }
static pos_t sel_b(void)  { return anchor < cur ? cur : anchor; }

static void set_cur(pos_t p)
{
    pos_t L = BLEN();

    if (p > L) p = L;
    if (p == 0) curpara = 1;
    else if (p == L) curpara = npara;
    else if (p > cur) curpara += buf_count(cur, p, '\n');
    else if (p < cur) curpara -= buf_count(p, cur, '\n');
    cur = p;
}

static void move_to(pos_t p, int shift)
{
    if (shift) {
        if (anchor == NOPOS) anchor = cur;
    } else
        anchor = NOPOS;
    set_cur(p);
}

static void u_reset(void);
static int hist_yield(void);

static void new_doc(void)
{
    cur = top = 0;
    anchor = NOPOS;
    curpara = 1;
    npara = buf_count(0, BLEN(), '\n') + 1;
    dirty = asdirty = 0;
    as_failed = 0;
    lastsave = kbd_ticks();
    goal = -1;
    neednorm = 0;
    u_reset();
}

/* ---------------------------------------------------------- edition */

static void del_range(pos_t a, pos_t b)
{
    pos_t k;

    anchor = NOPOS;               /* une ancre perimee pointerait n'importe ou */
    if (b <= a) return;
    set_cur(a);
    k = buf_count(a, b, '\n');
    buf_del(a, b - a);
    npara -= k;
    if (a < top) top = (top >= b) ? top - (b - a) : a;
    dirty = asdirty = 1;
    neednorm = 1;
}

static void del_sel(void)
{
    if (has_sel()) del_range(sel_a(), sel_b());
    anchor = NOPOS;
}

/* Insere une reserve au curseur ; rend le nombre d'octets inseres.
   nlknown : sauts de ligne de la reserve s'ils sont connus, sinon -1 */
static pos_t ins_store(int s, pos_t nlknown)
{
    pos_t n = st_len(s), done, nl;

    if (n == 0) return 0;
    done = st_insert(s, cur);
    while (done == 0 && hist_yield())
        done = st_insert(s, cur);
    if (done == 0) {
        say("Memoire pleine", 1);
        return 0;
    }
    nl = (done == n && nlknown >= 0) ? nlknown : buf_count(cur, cur + done, '\n');
    if (done < n) say("Memoire pleine : insertion incomplete", 1);
    if (cur < top) top += done;
    cur += done;
    curpara += nl;
    npara += nl;
    dirty = asdirty = 1;
    neednorm = 1;
    return done;
}

/* ------------------------------------------------------ annulation */

/*
 * Annulation a plusieurs niveaux, limitee seulement par la memoire.
 *
 * La modification courante (position u_p, texte supprime ST_UDEL, texte
 * insere ST_UINS) reste "ouverte" tant que la frappe peut l'allonger.
 * Les precedentes sont rangees dans le journal ST_JRN (pile) ; celles
 * qu'on a annulees sont dans ST_RED. Chronologiquement :
 *
 *      ST_JRN (de la plus ancienne a la plus recente), courante,
 *      puis ST_RED (de la plus recente a la plus ancienne)
 *
 * Annuler remplace, en u_p, le texte insere par le texte supprime ;
 * Refaire fait l'inverse. Une nouvelle modification vide ST_RED.
 *
 * Les frappes successives forment une seule modification, comme dans
 * Word : une suite de caracteres tapes (Retour arriere compris, pour
 * corriger une faute), une suite de Retour arriere, une suite de Suppr.
 * Tout autre commande (deplacement, collage...) termine le groupe.
 *
 * Quand la memoire manque (pour le texte comme pour l'historique), on
 * oublie d'abord ST_RED, puis les plus anciennes modifications : jamais
 * la courante. Si une modification ne peut pas etre memorisee, tout
 * l'historique est abandonne : il ne correspondrait plus au texte.
 */
#define R_NONE  0
#define R_TYPE  1                       /* frappe */
#define R_BKSP  2                       /* Retour arriere */
#define R_DEL   3                       /* Suppr */

static int u_have = 0;          /* une modification courante existe */
static int u_undone = 0;        /* ...et elle est annulee : Refaire possible */
static int u_lost = 0;          /* la derniere n'a pas pu etre memorisee */
static int u_run = R_NONE;      /* groupe qui peut encore s'allonger */
static int u_keep = 0;          /* la commande en cours l'a allonge */
static pos_t u_p = 0;

/* Oublie la modification courante seulement */
static void u_forget(void)
{
    st_clear(ST_UDEL);
    st_clear(ST_UINS);
    u_have = u_undone = 0;
    u_run = R_NONE;
}

/* Oublie tout l'historique */
static void u_reset(void)
{
    u_forget();
    st_clear(ST_JRN);
    st_clear(ST_RED);
    u_lost = 0;
}

/* Une modification n'a pas pu etre memorisee */
static void u_fail(void)
{
    u_reset();
    u_lost = 1;
}

/* Libere de la memoire : "refaire" d'abord, puis les plus anciennes
   modifications (jamais la courante). Rend 1 si quelque chose a ete libere. */
static int hist_yield(void)
{
    if (jn_len(ST_RED)) {
        st_clear(ST_RED);
        return 1;
    }
    if (jn_len(ST_JRN)) {
        jn_drop_oldest(ST_JRN);
        return 1;
    }
    return 0;
}

/* Ajoute un octet a une reserve de la modification courante */
static int u_putc(int s, int c)
{
    while (!st_putc(s, c))
        if (!hist_yield()) return 0;
    return 1;
}

/* Le groupe en cours peut-il s'allonger en genre "run" ? */
static int u_cont(int run)
{
    return u_have && !u_undone && u_run == run;
}

/* La modification courante rejoint le journal. Rend 0 si elle n'a pas
   pu y etre rangee : l'historique est alors abandonne. */
static int u_commit(void)
{
    if (!u_have) return 1;
    if (u_undone || (st_len(ST_UDEL) == 0 && st_len(ST_UINS) == 0)) {
        u_forget();                     /* annulee (rien a refaire) ou vide */
        return 1;
    }
    while (!jn_push(ST_JRN, u_p))
        if (!jn_drop_oldest(ST_JRN)) {
            u_reset();
            return 0;
        }
    u_forget();
    return 1;
}

/* Nouvelle modification en a : [a, b) va etre supprime */
static void u_begin(pos_t a, pos_t b, int run)
{
    st_clear(ST_RED);                   /* plus de "refaire" */
    u_commit();
    u_lost = 0;
    u_p = a;
    while (!st_set(ST_UDEL, a, b))
        if (!hist_yield()) {
            u_fail();
            return;
        }
    u_have = 1;
    u_run = run;
    u_keep = 1;
}

/* Suppression de [a, b) d'un seul coup (selection, mot, couper) */
static void del_rec(pos_t a, pos_t b)
{
    if (b > a) u_begin(a, b, R_NONE);
    del_range(a, b);
}

static void del_sel_rec(void)
{
    if (has_sel()) del_rec(sel_a(), sel_b());
    anchor = NOPOS;
}

/* Retour arriere d'un caractere (sans selection) */
static void bksp_char(void)
{
    int c = buf_at(cur - 1);
    pos_t li = st_len(ST_UINS);

    if (u_cont(R_TYPE) && li > 0 && cur == u_p + li) {
        st_unputc(ST_UINS);             /* faute corrigee pendant la frappe */
        u_keep = 1;
    } else if ((u_cont(R_TYPE) || u_cont(R_BKSP)) && li == 0 &&
               cur == u_p && st_pushc(ST_UDEL, c)) {
        u_p--;                          /* le groupe recule */
        u_keep = 1;
    } else
        u_begin(cur - 1, cur, R_BKSP);
    del_range(cur - 1, cur);
}

/* Suppr d'un caractere (sans selection) */
static void del_char(void)
{
    if (u_cont(R_DEL) && st_len(ST_UINS) == 0 && cur == u_p) {
        if (u_putc(ST_UDEL, buf_at(cur)))
            u_keep = 1;
        else
            u_fail();
    } else
        u_begin(cur, cur + 1, R_DEL);
    del_range(cur, cur + 1);
}

/* La courante ne convient pas : va chercher dans les journaux la
   modification a annuler (redo = 0) ou a refaire (redo = 1).
   Rend 0 s'il n'y en a pas. */
static int u_fetch(int redo)
{
    pos_t p;

    if (!redo) {
        if (jn_len(ST_JRN) == 0) return 0;
        if (u_have) {                   /* la courante, annulee, passe dans "refaire" */
            while (!jn_push(ST_RED, u_p))
                if (!jn_drop_oldest(ST_JRN)) return 0;
            u_forget();
        }
        while (!jn_pop(ST_JRN, &p))
            if (jn_len(ST_JRN) == 0 || !hist_yield()) return 0;
        u_have = 1;
        u_undone = 0;
    } else {
        if (jn_len(ST_RED) == 0) return 0;
        if (u_have && !u_commit()) return 0;
        while (!jn_pop(ST_RED, &p))
            if (jn_len(ST_RED) == 0 || !hist_yield()) return 0;
        u_have = 1;
        u_undone = 1;
    }
    u_p = p;
    u_run = R_NONE;
    return 1;
}

/* Annuler (redo = 0) ou refaire (redo = 1) */
static void do_undo(int redo)
{
    pos_t rem, want, done;

    if (!u_have || u_undone != redo) {
        if (!u_fetch(redo)) {
            if (u_lost)
                say("Annulation impossible : memoire insuffisante", 1);
            else
                say(redo ? "Rien a refaire" : "Rien a annuler", 0);
            return;
        }
    }
    rem = st_len(redo ? ST_UDEL : ST_UINS);
    want = st_len(redo ? ST_UINS : ST_UDEL);
    if (u_p + rem > BLEN()) {           /* ne devrait jamais arriver */
        u_reset();
        say("Annulation impossible", 1);
        return;
    }
    anchor = NOPOS;
    set_cur(u_p);
    del_range(u_p, u_p + rem);
    done = ins_store(redo ? ST_UINS : ST_UDEL, -1);
    if (done < want) {                  /* memoire pleine : a moitie fait */
        u_reset();
        return;
    }
    if (!redo && want) anchor = u_p;    /* texte retabli selectionne */
    u_undone = !redo;
    u_run = R_NONE;
    say(redo ? "Modification refaite" : "Modification annulee", 0);
}

static void type_char(int c)
{
    if (has_sel()) {
        u_begin(sel_a(), sel_b(), R_TYPE);
        del_sel();
    } else if (u_cont(R_TYPE) && cur == u_p + st_len(ST_UINS))
        u_keep = 1;                     /* la frappe continue */
    else
        u_begin(cur, cur, R_TYPE);
    if (!insmode && c != '\n' && cur < BLEN() && buf_at(cur) != '\n') {
        if (u_have && !u_putc(ST_UDEL, buf_at(cur))) u_fail();
        del_range(cur, cur + 1);
    }
    while (!buf_insch(cur, c))
        if (!hist_yield()) {
            say("Memoire pleine", 1);
            return;
        }
    if (u_have && !u_putc(ST_UINS, c)) u_fail();
    if (cur < top) top++;
    cur++;
    if (c == '\n') { npara++; curpara++; }
    dirty = asdirty = 1;
    neednorm = 1;
}

/* --------------------------------------------------------- mouvements */

static void line_up(int shift)
{
    pos_t r = row_start(cur);

    if (goal < 0) goal = col_of(r, cur);
    if (r == 0) {
        if (shift) move_to(0, shift);
        return;
    }
    move_to(pos_at_col(row_start(r - 1), goal), shift);
}

static void line_down(int shift)
{
    pos_t r = row_start(cur), e;

    if (goal < 0) goal = col_of(r, cur);
    e = lay_row(r, (cell_t *)0, 0);
    if (e > BLEN()) {
        if (shift) move_to(BLEN(), shift);
        return;
    }
    move_to(pos_at_col(e, goal), shift);
}

static void page_down(int shift)
{
    pos_t r = row_start(cur), e, L = BLEN();
    int i;

    if (goal < 0) goal = col_of(r, cur);
    for (i = 0; i < trows - 1; i++) {
        e = lay_row(r, (cell_t *)0, 0);
        if (e > L) break;
        r = e;
        e = lay_row(top, (cell_t *)0, 0);
        if (e <= L) top = e;
    }
    move_to(pos_at_col(r, goal), shift);
}

static void page_up(int shift)
{
    pos_t r = row_start(cur);
    int i;

    if (goal < 0) goal = col_of(r, cur);
    for (i = 0; i < trows - 1 && r > 0; i++) {
        r = row_start(r - 1);
        if (top > 0) top = row_start(top - 1);
    }
    move_to(pos_at_col(r, goal), shift);
}

static pos_t row_end(pos_t p)
{
    pos_t e = lay_row(row_start(p), (cell_t *)0, 0);
    return e > BLEN() ? BLEN() : e - 1;
}

static int isword(int c)
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') || c == '_' || c >= 128;
}

/* Debut du mot precedent / du mot suivant (convention DOS et Word) */
static pos_t word_left(pos_t p)
{
    while (p > 0 && !isword(buf_at(p - 1))) p--;
    while (p > 0 && isword(buf_at(p - 1))) p--;
    return p;
}

static pos_t word_right(pos_t p)
{
    pos_t L = BLEN();

    while (p < L && isword(buf_at(p))) p++;
    while (p < L && !isword(buf_at(p))) p++;
    return p;
}

static pos_t para_up(pos_t p)
{
    pos_t q;

    if (p > 0 && buf_at(p - 1) == '\n') p--;
    q = buf_rfind(p, '\n');
    return q == NOPOS ? 0 : q + 1;
}

static pos_t para_down(pos_t p)
{
    pos_t q = buf_find(p, '\n');
    return q == NOPOS ? BLEN() : q + 1;
}

/* ------------------------------------------------------------ ecran */

/*
 * Ligne du bas : la bordure du cadre, ou le message en cours a sa
 * place (le texte garde ses 23 rangees dans les deux cas).
 */
static void draw_bottom(void)
{
    int r = TROW0 + TROWS, a;

    if (msg) {
        a = msg_warn ? A_WARN : A_STAT;
        scr_fill(r, 0, SCOLS, ' ', a);
        scr_puts(r, 1, msg, a);
    } else {
        scr_fill(r, 0, SCOLS, 0xC4, A_FRAME);
        scr_fill(r, 0, 1, 0xC0, A_FRAME);
        scr_fill(r, SCOLS - 1, 1, 0xD9, A_FRAME);
    }
}

static void draw_frame(void)
{
    int r;

    scr_fill(0, 0, SCOLS, 0xC4, A_FRAME);
    scr_fill(0, 0, 1, 0xDA, A_FRAME);
    scr_fill(0, SCOLS - 1, 1, 0xBF, A_FRAME);
    for (r = TROW0; r < TROW0 + TROWS; r++) {
        scr_fill(r, 0, 1, 0xB3, A_FRAME);
        scr_fill(r, SCOLS - 1, 1, 0xB3, A_FRAME);
    }
    draw_bottom();
}

/*
 * Barre de defilement verticale, comme EDIT, dans la colonne droite
 * du cadre : fleches en haut et en bas, rail grise, curseur noir place
 * selon la position du curseur dans le texte. Non cliquable.
 */
static void draw_scroll(void)
{
    pos_t L = BLEN();
    int nrail = TROWS - 2, k;

    scr_fill(TROW0, SCOLS - 1, 1, 0x18, A_SBAR);                /* fleche haut */
    scr_fill(TROW0 + TROWS - 1, SCOLS - 1, 1, 0x19, A_SBAR);    /* fleche bas */
    for (k = 0; k < nrail; k++)
        scr_fill(TROW0 + 1 + k, SCOLS - 1, 1, 0xB0, A_SBAR);    /* rail */
    k = L ? (int)((unsigned long)cur * (nrail - 1) / L) : 0;
    scr_fill(TROW0 + 1 + k, SCOLS - 1, 1, ' ', A_THUMB);        /* curseur */
}

/* Nom du fichier centre dans le haut du cadre, en negatif */
static void draw_title(void)
{
    char t[40], *p, *base;
    int n = 0;

    base = fname;
    for (p = fname; *p; p++)
        if (*p == '\\' || *p == '/' || *p == ':') base = p + 1;
    if (!*base) base = "SANS-NOM";
    t[n++] = ' ';
    for (p = base; *p && n < 30; p++)
        t[n++] = (*p >= 'a' && *p <= 'z') ? (char)(*p - 32) : *p;
    if (dirty) { t[n++] = ' '; t[n++] = '*'; }
    t[n++] = ' ';
    t[n] = 0;
    scr_fill(0, 1, SCOLS - 2, 0xC4, A_FRAME);
    scr_puts(0, (SCOLS - n) / 2, t, A_TITLE);
}

static void ensure_visible(void)
{
    pos_t rc, r, L = BLEN();
    int i, lim = 4 * trows;

    if (top > L) top = L;
    if (neednorm) {
        top = row_start(top);
        neednorm = 0;
    }
    rc = row_start(cur);
    if (rc <= top) {
        top = rc;
        return;
    }
    r = top;
    i = 0;
    while (i < lim && r < rc) {
        rs[i++] = r;
        r = lay_row(r, (cell_t *)0, 0);
    }
    if (r == rc) {
        rs[i] = r;
        if (i >= trows) top = rs[i - trows + 1];
        return;
    }
    /* curseur loin : on le place en bas d'ecran */
    top = rc;
    for (i = 0; i < trows - 1 && top > 0; i++)
        top = row_start(top - 1);
}

static void render(void)
{
    pos_t r, L = BLEN();
    int i;

    ensure_visible();
    lay_cur = cur;
    lay_curcol = -1;
    if (has_sel()) {
        lay_sa = sel_a();
        lay_sb = sel_b();
    } else
        lay_sa = lay_sb = 0;

    crow = -1;
    r = top;
    for (i = 0; i < trows; i++) {
        if (r > L) {
            scr_fill(TROW0 + i, TCOL0, TCOLS, ' ', A_TEXT);
            continue;
        }
        r = lay_row(r, scr_sh + (TROW0 + i) * SCOLS + TCOL0, TCOLS);
        if (crow < 0 && lay_curcol >= 0) {
            crow = i;
            ccol = lay_curcol;
        }
    }
#ifdef EDW_CHECK
    if (crow < 0 || curpara != buf_count(0, cur, '\n') + 1 ||
        npara != buf_count(0, L, '\n') + 1 || row_start(top) != top) {
        printf("INCOHERENCE cur=%ld top=%ld crow=%d par=%ld/%ld\n",
               cur, top, crow, curpara, npara);
        exit(3);
    }
#endif
    if (crow < 0) { crow = 0; ccol = 0; }
    draw_title();
    draw_scroll();
    draw_bottom();
    scr_flush();
    scr_cursor(TROW0 + crow, TCOL0 + ccol);
    scr_shape(insmode);
}

/* -------------------------------------------- saisie en ligne d'etat */

static int prompt(char *label, char *buf, int max)
{
    char line[SCOLS + 1];
    int n = strlen(buf), k, sh, ll = strlen(label);

    for (;;) {
        scr_fill(SROWS - 1, 0, SCOLS, ' ', A_STAT);
        strcpy(line, label);
        strcat(line, buf);
        scr_puts(SROWS - 1, 1, line, A_STAT);
        scr_flush();
        scr_cursor(SROWS - 1, 1 + ll + n);
        while (!kbd_pending()) kbd_idle();
        k = kbd_get(&sh);
        if (k == K_ENTER) return 1;
        if (k == K_ESC) return 0;
        if (k == K_BKSP) {
            if (n) buf[--n] = 0;
        } else if (k >= 32 && k < 256 && k != 127 && n < max &&
                   1 + ll + n < SCOLS - 1) {
            buf[n++] = (char)k;
            buf[n] = 0;
        }
    }
}

/* ------------------------------------------------------- fichiers */

/* Boite d'erreur : un seul bouton, a valider (Entree, Espace ou Echap) */
static void err_box(char *text)
{
    static char *ok[1] = { "OK" };

    dlg_box("Erreur", text, ok, 1, 0, 0);
    render();                   /* efface la boite meme si des touches attendent */
}

/*
 * NOM.SAV n'existe que si une session s'est terminee anormalement :
 * ED le supprime a chaque enregistrement et quand on abandonne les
 * modifications. A l'ouverture de NOM, on demande donc quoi en faire.
 */
#define S_NONE   0              /* pas de NOM.SAV */
#define S_TAKE   1              /* recuperer le texte de NOM.SAV */
#define S_DROP   2              /* supprimer NOM.SAV */
#define S_CANCEL 3              /* quitter (lancement) ou annuler (Ctrl+O) */

static int sav_choice(char *name, int atlaunch)
{
    static char t[100];
    char sav[90], *b[3], *p, *base;
    int r, nb;

    if (!fio_hassav(name)) return S_NONE;
    fio_savname(name, sav);
    base = sav;
    for (p = sav; *p; p++)
        if (*p == '\\' || *p == '/' || *p == ':') base = p + 1;
    strcpy(t, base);
    strcat(t, " existe : la session precedente s'est\n"
              "arretee anormalement.\n\nQue souhaitez-vous faire ?");
    b[0] = "Recuperer";
    if (fio_exists(name)) {
        b[1] = "Supprimer la sauvegarde";
        b[2] = atlaunch ? "Quitter ED" : "Annuler";
        nb = 3;
    } else {                    /* NOM absent : la sauvegarde est la seule copie */
        b[1] = atlaunch ? "Quitter ED" : "Annuler";
        nb = 2;
    }
    r = dlg_box("Erreur", t, b, nb, 0, nb - 1);
    render();
    if (r == 0) return S_TAKE;
    return (nb == 3 && r == 1) ? S_DROP : S_CANCEL;
}

/* Entier non signe en decimal ; rend la fin de la chaine */
static char *utos(unsigned v, char *d)
{
    char t[6];
    int n = 0;

    do {
        t[n++] = (char)('0' + v % 10);
        v /= 10;
    } while (v);
    while (n) *d++ = t[--n];
    *d = 0;
    return d;
}

/* Ctrl+P : a propos (version, mode et occupation memoire) */
static void about_box(void)
{
    static char *ok[1] = { "OK" };
    static char t[240];
    unsigned kc, kh;
    char *q;

    buf_mem(&kc, &kh);
    strcpy(t, "ED version " ED_VERSION "\n\n"
              "Editeur de texte pour MS-DOS\n"
              "Turbo C 2.0, modele small\n\n"
              "Texte en memoire ");
    strcat(t, buf_where[0] == 'E' ? "paginee (EMS)" : "conventionnelle");
    strcat(t, "\nMemoire utilisee : ");
    q = utos(kc, t + strlen(t));
    if (kh) {
        strcpy(q, " + ");
        q = utos(kh, q + 3);
    }
    strcpy(q, kh ? " Ko (conventionnelle + EMS)" : " Ko (conventionnelle)");
    dlg_box("A propos", t, ok, 1, 0, 0);
    render();
}

static int do_save(int asname)
{
    char nm[81], old[81];

    strcpy(old, fname);
    if (asname || !fname[0]) {
        strcpy(nm, fname);
        if (!prompt("Enregistrer sous : ", nm, 79) || !nm[0])
            return 0;
        strcpy(fname, nm);
    }
    switch (fio_save(fname)) {
    case FIO_OK:
        break;
    case FIO_VERIFY:
        strcpy(fname, old);
        err_box("Le texte n'a PAS ete enregistre :\n"
                "la relecture du fichier a echoue.\n"
                "L'original est intact.\n\n"
                "Enregistrez-le ailleurs avec Ctrl+Maj+S.");
        return 0;
    default:
        strcpy(fname, old);
        err_box("Le texte n'a PAS ete enregistre :\n"
                "erreur d'ecriture (disque plein ou protege ?).\n\n"
                "Enregistrez-le ailleurs avec Ctrl+Maj+S.");
        return 0;
    }
    dirty = asdirty = 0;
    lastsave = kbd_ticks();
    fio_unsav(fname);                   /* la sauvegarde auto n'a plus lieu d'etre */
    if (strcmp(old, fname) != 0) fio_unsav(old);
    return 1;
}

static int confirm_discard(void)
{
    static char *b[3] = { "Enregistrer", "Ne pas enregistrer", "Annuler" };
    int r;

    if (!dirty) return 1;
    r = dlg_box("Modifications",
                "Le texte a ete modifie depuis le dernier\nenregistrement.\n\nQue souhaitez-vous faire ?",
                b, 3, 0, 2);
    render();
    if (r == 2) return 0;
    if (r == 0) return do_save(0);
    fio_unsav(fname);                   /* modifications abandonnees */
    return 1;
}

/*
 * Rend 1 si le document courant a ete remplace.
 * how : le choix S_* fait par sav_choice() pour ce fichier.
 *   S_TAKE : on charge NOM.SAV sous le nom NOM, marque modifie ; rien
 *            n'est renomme ni supprime : NOM reste intact jusqu'au
 *            prochain enregistrement, qui supprime NOM.SAV.
 *   S_DROP : on supprime NOM.SAV puis on charge NOM.
 */
static int load_file(char *name, int isnew_ok, int how)
{
    char sav[90];
    int r;

    if (how == S_DROP) fio_unsav(name);
    if (how == S_TAKE) {
        fio_savname(name, sav);
        r = fio_load(sav);
    } else
        r = fio_load(name);

    if (r == FIO_NOFILE) {
        if (!isnew_ok) {
            say("Fichier introuvable", 1);
            return 0;
        }
        buf_reset();
        strcpy(fname, name);
        new_doc();
        say("Nouveau fichier", 0);
        return 1;
    }
    strcpy(fname, name);
    new_doc();
    if (how == S_TAKE) dirty = 1;       /* different du fichier sur disque */
    if (r == FIO_NOMEM || r == FIO_ERR) {
        fname[0] = 0;           /* ne pas ecraser l'original par un texte tronque */
        dirty = asdirty = 1;
        if (r == FIO_NOMEM)
            err_box("Le fichier est trop grand pour la memoire :\n"
                    "seul son debut a ete charge.\n\n"
                    "Enregistrez-le sous un autre nom (Ctrl+Maj+S)\n"
                    "pour ne pas ecraser l'original.");
        else
            err_box("Erreur de lecture : le fichier n'a pas ete\n"
                    "lu en entier.\n\n"
                    "Enregistrez le texte sous un autre nom (Ctrl+Maj+S)\n"
                    "pour ne pas ecraser l'original.");
    }
    return 1;
}

static void do_find(int again)
{
    pos_t start, r;
    int n;

    if (!again || !findstr[0])
        if (!prompt("Chercher : ", findstr, 63) || !findstr[0])
            return;
    n = strlen(findstr);
    start = has_sel() ? sel_a() + 1 : cur;
    r = buf_search(start, findstr, n);
    if (r == NOPOS) {
        r = buf_search(0, findstr, n);
        if (r != NOPOS) say("Recherche reprise au debut", 0);
    }
    if (r == NOPOS) {
        say("Introuvable", 0);
        return;
    }
    anchor = NOPOS;
    set_cur(r);
    anchor = r;
    set_cur(r + n);
}

/* -------------------------------------------------- presse-papiers */

static int do_copy(void)
{
    pos_t a, b;

    if (!has_sel()) {
        say("Aucune selection", 0);
        return 0;
    }
    a = sel_a();
    b = sel_b();
    while (!buf_setclip(a, b))
        if (!hist_yield()) {
            say("Memoire insuffisante pour copier", 1);
            return 0;
        }
    clipnl = buf_count(a, b, '\n');
    return 1;
}

static void do_paste(void)
{
    pos_t done;
    int hadsel = has_sel();

    if (buf_cliplen() == 0) return;
    if (hadsel) {
        u_begin(sel_a(), sel_b(), R_NONE);
        del_sel();
    } else
        u_begin(cur, cur, R_NONE);
    done = ins_store(ST_CLIP, clipnl);
    if (done == 0) {
        if (!hadsel) u_forget();        /* rien n'a change */
    } else if (u_have) {
        while (!st_copy(ST_UINS, ST_CLIP, done))
            if (!hist_yield()) {
                u_fail();
                break;
            }
    }
}

/* ---------------------------------------------- sauvegarde automatique */

/*
 * Pas de processus en arriere-plan sous DOS : on regarde l'horloge du
 * BIOS pendant l'attente du clavier et apres chaque touche. Une minute
 * apres la derniere sauvegarde, on enregistre dans NOM.SAV des que
 * l'utilisateur marque une pause de 2 s, ou au bout de 2 minutes s'il
 * tape sans arret. NOM et NOM.BAK ne sont pas touches.
 */
static int autosave_due(int idle)
{
    unsigned long now = kbd_ticks();

    if (!asdirty) return 0;
    if (now < lastsave || now < lastkey) {  /* minuit : on repart */
        lastsave = lastkey = now;
        return 0;
    }
    if (now - lastsave >= T_FORCE) return 1;
    return idle && now - lastsave >= T_AUTO && now - lastkey >= T_PAUSE;
}

/*
 * Silencieuse tant qu'elle marche. Si elle echoue, une boite le dit
 * une seule fois : on reessaie chaque minute sans redire, jusqu'au
 * prochain succes.
 */
static void autosave(void)
{
    lastsave = kbd_ticks();
    if (fio_autosave(fname) == FIO_OK) {
        asdirty = 0;
        as_failed = 0;
    } else if (!as_failed) {
        as_failed = 1;
        err_box("La sauvegarde automatique a echoue.\n"
                "Votre texte n'est plus protege en cas de panne.\n\n"
                "Enregistrez-le ailleurs avec Ctrl+Maj+S.");
    }
}

/* -------------------------------------------------------- commandes */

static void handle(int k, int shift)
{
    int cmd = key_cmd(k), keepgoal = 0;
    pos_t p;

    u_keep = 0;
    switch (cmd) {
    case C_NONE:
        if (k >= 32 && k < 256 && k != 127) type_char(k);
        break;
    case C_LEFT:
        if (!shift && has_sel()) { p = sel_a(); anchor = NOPOS; set_cur(p); }
        else move_to(cur ? cur - 1 : 0, shift);
        break;
    case C_RIGHT:
        if (!shift && has_sel()) { p = sel_b(); anchor = NOPOS; set_cur(p); }
        else move_to(cur + 1, shift);
        break;
    case C_UP:       line_up(shift);   keepgoal = 1; break;
    case C_DOWN:     line_down(shift); keepgoal = 1; break;
    case C_PGUP:     page_up(shift);   keepgoal = 1; break;
    case C_PGDN:     page_down(shift); keepgoal = 1; break;
    case C_HOME:     move_to(row_start(cur), shift); break;
    case C_END:      move_to(row_end(cur), shift); break;
    case C_TOP:      move_to(0, shift); break;
    case C_BOTTOM:   move_to(BLEN(), shift); break;
    case C_WLEFT:    move_to(word_left(cur), shift); break;
    case C_WRIGHT:   move_to(word_right(cur), shift); break;
    case C_PARUP:    move_to(para_up(cur), shift); break;
    case C_PARDOWN:  move_to(para_down(cur), shift); break;
    case C_BKSP:
        if (has_sel()) del_sel_rec();
        else if (cur > 0) bksp_char();
        break;
    case C_DEL:
        if (has_sel()) del_sel_rec();
        else if (cur < BLEN()) del_char();
        break;
    case C_WBKSP:
        if (has_sel()) del_sel_rec();
        else del_rec(word_left(cur), cur);
        break;
    case C_WDEL:
        if (has_sel()) del_sel_rec();
        else del_rec(cur, word_right(cur));
        break;
    case C_ENTER:    type_char('\n'); break;
    case C_TAB:      type_char('\t'); break;
    case C_INS:      insmode = !insmode; break;
    case C_ESC:      anchor = NOPOS; break;
    case C_SELALL:   anchor = 0; set_cur(BLEN()); break;
    case C_COPY:     do_copy(); break;
    case C_CUT:      if (do_copy()) del_sel_rec(); break;
    case C_PASTE:    do_paste(); break;
    case C_FIND:     do_find(0); break;
    case C_FINDNEXT: do_find(1); break;
    case C_SAVE:     do_save(shift); break;
    case C_OPEN: {
        char nm[81];
        int how;

        /* le nom d'abord, puis NOM.SAV, puis le sort du texte en cours :
           Annuler ne doit rien avoir touche */
        nm[0] = 0;
        if (prompt("Ouvrir : ", nm, 79) && nm[0]) {
            how = sav_choice(nm, 0);
            if (how != S_CANCEL && confirm_discard())
                load_file(nm, 0, how);
        }
        break;
    }
    case C_NEW:
        if (confirm_discard()) {
            buf_reset();
            fname[0] = 0;
            new_doc();
        }
        break;
    case C_QUIT:
        if (confirm_discard()) quit = 1;
        break;
    case C_UNDO:     do_undo(shift); break;     /* Maj : refaire */
    case C_REDO:     do_undo(1); break;
    case C_ABOUT:    about_box(); break;
    }
    if (!keepgoal) goal = -1;
    if (!u_keep) u_run = R_NONE;        /* le groupe de frappe est clos */
}

static void usage(void)
{
    puts("ED version " ED_VERSION " - editeur de texte avec retour automatique a la ligne");
    puts("Usage : ED [fichier]");
    puts("Limites :");
    puts("    - environ 500ko en m�moire conventionnelle");
    puts("    - 8Mo en memoire paginee (HIMEM.SYS /NUMHANDLES=128)");
    puts("    - Prevoir environ trois fois la taille du texte en memoire");
    puts("");
    puts("Ctrl+P dans ED : a propos (version).");
}

int main(int argc, char *argv[])
{
    int i, k, shift, oldbrk, how;
    char *file = 0, *a;

    for (i = 1; i < argc; i++) {
        a = argv[i];
        if (a[0] == '/' || a[0] == '-') {
            usage();
            return 0;
        } else
            file = a;
    }
    if (file && strlen(file) > 79) {
        puts("ED : nom de fichier trop long.");
        return 1;
    }
    if (!buf_init()) {
        puts("ED : memoire insuffisante.");
        return 1;
    }
    kbd_init();
    if (!scr_init()) {
        puts("ED : mode video non gere.");
        buf_done();
        return 1;
    }
    trows = TROWS;
    draw_frame();
    lay_w = LAYW;

    ctrlbrk(on_break);
    harderr(on_crit);
    oldbrk = getcbrk();
    setcbrk(0);

    fname[0] = 0;
    msg = 0;
    how = sav_choice(file ? file : "", 1);
    if (how == S_CANCEL)
        quit = 1;
    else if (file || how == S_TAKE)
        load_file(file ? file : "", 1, how);
    else {
        if (how == S_DROP) fio_unsav("");
        new_doc();
    }

    while (!quit) {
        if (!kbd_pending()) {
            render();
            while (!kbd_pending()) {    /* attente du clavier (HLT) */
                if (autosave_due(1)) {
                    autosave();
                    render();
                }
                if (msg && !msg_warn && kbd_ticks() - msg_t >= T_MSG) {
                    msg = 0;            /* l'information a assez dure */
                    render();
                }
                kbd_idle();
            }
        }
        k = kbd_get(&shift);
        lastkey = kbd_ticks();
        msg = 0;
        handle(k, shift);
        if (autosave_due(0))            /* frappe continue : 2 min maxi */
            autosave();
    }

    scr_done();
    setcbrk(oldbrk);
    buf_done();
    return 0;
}
