/*
 * ED.H - Declarations communes de l'editeur ED
 *
 * Cible : MS-DOS reel 16 bits, Borland Turbo C 2.0, modele small.
 * Le texte, de taille quelconque, est decoupe en blocs de 16 Ko :
 * pages EMS si possible, sinon blocs DOS en memoire conventionnelle.
 * Une position est un entier 32 bits.
 */

/* Numero de version : defini ici, et nulle part ailleurs */
#define ED_VERSION "418"

#ifndef EDW_H
#define EDW_H

#include <dos.h>

typedef unsigned short cell_t;      /* caractere + attribut video */
typedef long pos_t;                 /* position dans le texte */

#define NOPOS   (-1L)               /* "aucune position" */

#define SCOLS   80                  /* ecran 80x25 uniquement */
#define SROWS   25

/* Couleurs facon EDIT */
#define A_TEXT  0x17                /* gris sur bleu */
#define A_SEL   0x71                /* bleu sur gris : selection */
#define A_FRAME 0x17                /* cadre */
#define A_TITLE 0x71                /* nom du fichier, en negatif */
#define A_STAT  0x30                /* noir sur cyan : message d'information */
#define A_WARN  0x4F                /* blanc sur rouge : avertissement */
#define A_SBAR  0x70                /* barre de defilement : noir sur gris */
#define A_THUMB 0x00                /* curseur de la barre : pave noir */

/* Boites de dialogue (DLG.C) */
#define A_DLG   0x70                /* fond de la boite : noir sur gris */
#define A_DERR  0x4F                /* titre "Erreur" : blanc sur rouge */
#define A_DTIT  0x30                /* autre titre : noir sur cyan */
#define A_DSEL  0x1F                /* bouton choisi : blanc sur bleu */
#define A_DHOT  0x74                /* lettre d'acces rapide : rouge sur gris */
#define A_DHOTS 0x1E                /* ...sur le bouton choisi : jaune sur bleu */
#define A_DSHAD 0x08                /* ombre : gris fonce sur noir */

/* Zone de texte a l'interieur du cadre */
#define TROW0   1                   /* premiere rangee de texte */
#define TROWS   23                  /* rangees 1 a 23, la bordure basse est en 24 */
#define TCOL0   1                   /* premiere colonne de texte */
#define TCOLS   78                  /* colonnes 1 a 78 */
/* Largeur de coupure des rangees : une colonne de moins que la zone de
 * texte, pour que le curseur puisse se placer apres le dernier caractere
 * d'une rangee pleine. Seul endroit ou cette largeur est definie. */
#define LAYW    (TCOLS - 1)

/* ------------------------------------------------------------ BUF.C */
/*
 * Le texte est une suite de blocs de 16 Ko au plus (voir BUF.C).
 * Les positions vont de 0 a BLEN(). Un pointeur rendu par buf_span()
 * n'est valable que jusqu'au prochain appel d'une fonction buf_*.
 */
extern pos_t b_total;               /* longueur du texte */
extern char *buf_where;             /* "EMS" ou "DOS" */

#define BLEN()    (b_total)

int   buf_init(void);
void  buf_done(void);
void  buf_reset(void);
int   buf_at(pos_t p);
unsigned char far *buf_span(pos_t p, unsigned *n);
int   buf_insch(pos_t p, int c);
int   buf_ins(pos_t p, char *s, unsigned n);
void  buf_del(pos_t p, pos_t n);
int   buf_setclip(pos_t a, pos_t b);
pos_t buf_cliplen(void);
pos_t buf_paste(pos_t p);

/* Reserves : copies de texte hors du document (pages EMS ou DOS) */
#define ST_CLIP   0                 /* presse-papiers */
#define ST_UDEL   1                 /* annulation : texte supprime */
#define ST_UINS   2                 /* annulation : texte insere */
#define ST_JRN    3                 /* journal d'annulation (pile) */
#define ST_RED    4                 /* journal de refaire (pile) */
#define NST       5

void  st_clear(int s);
pos_t st_len(int s);
int   st_set(int s, pos_t a, pos_t b);
int   st_copy(int d, int src, pos_t n);
int   st_putc(int s, int c);
void  st_unputc(int s);
int   st_pushc(int s, int c);
pos_t st_insert(int s, pos_t p);

/* Journaux : piles de modifications (position, texte supprime UDEL,
   texte insere UINS), memorisees dans une reserve */
pos_t jn_len(int j);
int   jn_push(int j, pos_t p);          /* UDEL/UINS -> sommet ; 0 si memoire pleine */
int   jn_pop(int j, pos_t *p);          /* sommet -> UDEL/UINS ; 0 si vide ou memoire pleine */
int   jn_drop_oldest(int j);            /* oublie les plus anciennes ; 0 si vide */
pos_t buf_count(pos_t a, pos_t b, int ch);
pos_t buf_find(pos_t p, int ch);
pos_t buf_rfind(pos_t p, int ch);
pos_t buf_search(pos_t from, char *pat, int n);
void  buf_mem(unsigned *conv, unsigned *high);
int   buf_check(void);

/* ------------------------------------------------------------ LAY.C */
extern int   lay_w, lay_tab;
extern pos_t lay_cur, lay_sa, lay_sb;
extern int   lay_curcol;

pos_t lay_row(pos_t s, cell_t *out, int ncols);
pos_t row_start(pos_t p);
int   col_of(pos_t r, pos_t p);
pos_t pos_at_col(pos_t r, int goal);

/* ------------------------------------------------------------ SCR.C */
extern cell_t scr_sh[SCOLS * SROWS];

int  scr_init(void);
void scr_done(void);
void scr_flush(void);
void scr_cursor(int row, int col);
void scr_shape(int insert);
void scr_puts(int row, int col, char *s, int attr);
void scr_fill(int row, int col, int n, int ch, int attr);

/* ------------------------------------------------------------ KBD.C */
void kbd_init(void);
int  kbd_pending(void);
int  kbd_get(int *shift);
int  key_cmd(int code);

/* ------------------------------------------------------------ DLG.C */
int  dlg_box(char *title, char *text, char *btn[], int nbtn, int def, int esc);

/* ------------------------------------------------------------ FIO.C */
#define FIO_OK      0
#define FIO_NOFILE  1
#define FIO_NOMEM   2
#define FIO_ERR     3
#define FIO_VERIFY  4

int fio_load(char *name);
int fio_save(char *name);
int  fio_autosave(char *name);
void fio_savname(char *name, char *sav);
void fio_unsav(char *name);
int  fio_hassav(char *name);
int  fio_exists(char *name);

/* ------------------------------------------------------------ KBD.C */
unsigned long kbd_ticks(void);
void kbd_idle(void);

/* ------------------------------------------------- Codes de touches */
/* Caractere ASCII tel quel (1..255), touche etendue = 0x100 | scancode */
#define KX(s)     (0x100 | (s))
#define CTRL(c)   ((c) & 0x1F)

#define K_UP      KX(0x48)
#define K_DOWN    KX(0x50)
#define K_LEFT    KX(0x4B)
#define K_RIGHT   KX(0x4D)
#define K_HOME    KX(0x47)
#define K_END     KX(0x4F)
#define K_PGUP    KX(0x49)
#define K_PGDN    KX(0x51)
#define K_INS     KX(0x52)
#define K_DEL     KX(0x53)
#define K_CLEFT   KX(0x73)
#define K_CRIGHT  KX(0x74)
#define K_CHOME   KX(0x77)
#define K_CEND    KX(0x75)
#define K_CPGUP   KX(0x84)
#define K_CPGDN   KX(0x76)
#define K_CUP     KX(0x8D)
#define K_CDOWN   KX(0x91)
#define K_CDEL    KX(0x93)

#define K_BKSP    8
#define K_TAB     9
#define K_ENTER   13
#define K_ESC     27
#define K_CBKSP   127

/* ------------------------------------------------------- Commandes */
enum {
    C_NONE = 0,
    C_LEFT, C_RIGHT, C_UP, C_DOWN, C_HOME, C_END, C_PGUP, C_PGDN,
    C_TOP, C_BOTTOM, C_WLEFT, C_WRIGHT, C_PARUP, C_PARDOWN,
    C_BKSP, C_DEL, C_WBKSP, C_WDEL, C_ENTER, C_TAB, C_INS, C_ESC,
    C_SELALL, C_COPY, C_CUT, C_PASTE, C_FIND, C_FINDNEXT,
    C_SAVE, C_OPEN, C_NEW, C_QUIT, C_UNDO, C_REDO, C_ABOUT
};

#endif
