/*
 * FIO.C - Chargement et enregistrement
 *
 * En memoire, les paragraphes sont separes par '\n' seul.
 * Au chargement : les '\r' sont retires, un Ctrl+Z marque la fin.
 * A l'enregistrement : '\n' redevient CR+LF. Voir fio_save() pour
 * l'ordre des operations (fichier temporaire, relecture, .BAK), et
 * fio_autosave() pour la sauvegarde automatique (NOM.SAV).
 */

#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include "ed.h"

#define IOBUF 1024

static char iob[IOBUF];

int fio_load(char *name)
{
    int fd, n, i, k, eof = 0, ret = FIO_OK;
    unsigned char c;

    fd = open(name, O_RDONLY | O_BINARY);
    if (fd < 0)
        return FIO_NOFILE;
    buf_reset();
    while (!eof && (n = read(fd, iob, IOBUF)) > 0) {
        k = 0;
        for (i = 0; i < n; i++) {       /* compactage sur place */
            c = (unsigned char)iob[i];
            if (c == '\r') continue;
            if (c == 0x1A) { eof = 1; break; }
            iob[k++] = (char)c;
        }
        if (k && !buf_ins(BLEN(), iob, (unsigned)k)) {
            ret = FIO_NOMEM;
            break;
        }
    }
    if (n < 0)
        ret = FIO_ERR;
    close(fd);
    return ret;
}

/* Meme nom avec une autre extension (ext commence par '.') */
static void ext_name(char *name, char *ext, char *out)
{
    char *dot = 0, *p;

    strcpy(out, name);
    for (p = out; *p; p++) {
        if (*p == '.') dot = p;
        else if (*p == '\\' || *p == '/' || *p == ':') dot = 0;
    }
    if (dot) *dot = 0;
    strcat(out, ext);
}

static int same_name(char *a, char *b)
{
    int ca, cb;

    for (;;) {
        ca = (unsigned char)*a++;
        cb = (unsigned char)*b++;
        if (ca >= 'a' && ca <= 'z') ca -= 32;
        if (cb >= 'a' && cb <= 'z') cb -= 32;
        if (ca != cb) return 0;
        if (ca == 0) return 1;
    }
}

/*
 * Relit le fichier ecrit et le compare au texte en memoire, '\n'
 * devant y figurer sous la forme CR+LF. Rend 1 si identique.
 */
static int verify(char *path)
{
    int fd, n, i, lf = 0, ok = 1;
    pos_t p = 0, L = BLEN();
    unsigned avail = 0;
    unsigned char far *s = 0;
    unsigned char c;

    fd = open(path, O_RDONLY | O_BINARY);
    if (fd < 0)
        return 0;
    while (ok && (n = read(fd, iob, IOBUF)) > 0) {
        for (i = 0; i < n; i++) {
            if (lf) {
                c = '\n';
                lf = 0;
            } else {
                if (p >= L) { ok = 0; break; }
                if (avail == 0) {       /* tranche suivante du texte */
                    s = buf_span(p, &avail);
                    if (avail == 0) { ok = 0; break; }
                }
                c = *s++;
                avail--;
                p++;
                if (c == '\n') { c = '\r'; lf = 1; }
            }
            if ((unsigned char)iob[i] != c) { ok = 0; break; }
        }
    }
    if (n < 0 || lf || p != L)
        ok = 0;
    close(fd);
    return ok;
}

/* Ecrit le texte dans tmp (CR+LF), puis le relit et le compare */
static int write_tmp(char *tmp)
{
    int fd, k = 0, err = 0;
    pos_t p = 0, L = BLEN();
    unsigned n, i;
    unsigned char far *s;

    fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, S_IREAD | S_IWRITE);
    if (fd < 0)
        return FIO_ERR;
    while (p < L && !err) {
        s = buf_span(p, &n);
        if (n == 0) break;
        for (i = 0; i < n; i++) {
            if (k >= IOBUF - 1) {       /* place pour CR+LF */
                if (write(fd, iob, k) != k) { err = 1; break; }
                k = 0;
            }
            if (s[i] == '\n') iob[k++] = '\r';
            iob[k++] = (char)s[i];
        }
        p += n;
    }
    if (!err && k && write(fd, iob, k) != k)
        err = 1;
    if (close(fd) != 0)
        err = 1;
    if (err) {
        remove(tmp);
        return FIO_ERR;
    }
    if (!verify(tmp)) {
        remove(tmp);
        return FIO_VERIFY;
    }
    return FIO_OK;
}

/*
 * Enregistrement :
 *   1. ecriture dans NOM.$$$ ;
 *   2. relecture de NOM.$$$ et comparaison avec le texte en memoire ;
 *   3. l'original devient NOM.BAK (l'ancien .BAK est supprime) ;
 *   4. NOM.$$$ devient NOM.
 * A aucun moment le texte n'existe sous aucun nom : en cas d'echec,
 * l'original est intact (ou remis en place depuis NOM.BAK).
 */
int fio_save(char *name)
{
    char tmp[90], bak[90];
    int r, hasbak;

    if (strlen(name) > 80)
        return FIO_ERR;
    ext_name(name, ".$$$", tmp);
    ext_name(name, ".BAK", bak);
    if (same_name(tmp, name))
        return FIO_ERR;
    r = write_tmp(tmp);
    if (r != FIO_OK)
        return r;
    hasbak = !same_name(bak, name);
    if (hasbak) {
        remove(bak);
        rename(name, bak);              /* original absent : sans importance */
    } else
        remove(name);
    if (rename(tmp, name) != 0) {
        if (hasbak) rename(bak, name);  /* remettre l'original */
        return FIO_ERR;
    }
    return FIO_OK;
}

/* Nom de la sauvegarde automatique : NOM.SAV, ou SANS-NOM.SAV */
void fio_savname(char *name, char *sav)
{
    ext_name(name[0] ? name : "SANS-NOM", ".SAV", sav);
}

/*
 * Sauvegarde automatique dans NOM.SAV, sans toucher a NOM ni a NOM.BAK.
 * Meme precautions : fichier temporaire, relecture, puis renommage.
 */
int fio_autosave(char *name)
{
    char tmp[90], sav[90];
    int r;

    if (strlen(name) > 80)
        return FIO_ERR;
    fio_savname(name, sav);
    if (same_name(sav, name))           /* on edite un .SAV : ne pas l'ecraser */
        return FIO_OK;
    ext_name(sav, ".$$$", tmp);
    r = write_tmp(tmp);
    if (r != FIO_OK)
        return r;
    remove(sav);
    if (rename(tmp, sav) != 0) {
        remove(tmp);
        return FIO_ERR;
    }
    return FIO_OK;
}

/* Supprime NOM.SAV (apres un enregistrement, ou un abandon voulu) */
void fio_unsav(char *name)
{
    char sav[90];

    if (strlen(name) > 80) return;
    fio_savname(name, sav);
    if (same_name(sav, name)) return;   /* on edite un .SAV : le garder */
    remove(sav);
}

/* NOM.SAV existe-t-il ? */
int fio_hassav(char *name)
{
    char sav[90];
    int fd;

    if (strlen(name) > 80) return 0;
    fio_savname(name, sav);
    if (same_name(sav, name)) return 0; /* on edite un .SAV */
    fd = open(sav, O_RDONLY | O_BINARY);
    if (fd < 0) return 0;
    close(fd);
    return 1;
}

/* 1 si le fichier existe (nom vide : non) */
int fio_exists(char *name)
{
    int fd;

    if (!name[0]) return 0;
    fd = open(name, O_RDONLY | O_BINARY);
    if (fd < 0) return 0;
    close(fd);
    return 1;
}
