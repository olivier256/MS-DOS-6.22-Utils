/*
 * BUF.C - Texte de taille quelconque, en blocs de 16 Ko (ED)
 *
 * Le texte est une suite ordonnee de blocs. Chaque bloc occupe une
 * page de 16 Ko et contient de 1 a 16 384 octets, ranges a partir du
 * debut de la page. Une table en memoire proche donne, pour chaque
 * bloc : sa page, sa longueur, son nombre de sauts de ligne.
 *
 * Ou sont les pages :
 *   - EMS : pages logiques d'un seul handle, agrandi a la demande
 *     (fonction 51h, EMS 4.0). Pour lire ou ecrire un bloc, on place
 *     sa page dans l'un des 4 emplacements du cadre (fonction 44h) :
 *       emplacements 0 et 1 : blocs du texte pendant une modification ;
 *       emplacements 0 a 2  : lectures (affichage, recherche), le moins
 *                             recemment utilise est recycle ;
 *       emplacement 3       : reserves (presse-papiers, annulation).
 *   - sinon : chaque bloc est un bloc DOS de 16 Ko en memoire
 *     conventionnelle, adresse directement.
 *
 * Une frappe ne deplace des octets que dans un seul bloc (16 Ko au
 * plus). Un bloc plein qui recoit du texte est coupe en deux ; deux
 * blocs voisins qui tiennent ensemble dans 16 Ko sont recolles.
 *
 * Les compteurs de sauts de ligne par bloc permettent de compter les
 * paragraphes sans relire le texte (Ctrl+Fin, numero de paragraphe).
 *
 * Les reserves sont des copies de texte hors du document, rangees dans
 * des pages pleines sauf la derniere : le presse-papiers (ST_CLIP) et
 * les deux textes de l'annulation (ST_UDEL, ST_UINS).
 */

#include <dos.h>
#ifdef __TURBOC__
#include <mem.h>
#endif
#include "ed.h"

#define BLKSZ   16384u              /* taille d'un bloc = une page EMS */
#define MAXBLK  512                 /* blocs de texte : 4 a 8 Mo */
#define MAXST   512                 /* pages par reserve : 8 Mo */
#define MAXPG   (MAXBLK + NST * MAXST + 16)
#define GROW    16                  /* croissance EMS : 16 pages = 256 Ko */
#define NOPAGE  0xFFFFu

pos_t b_total = 0;
char *buf_where = "DOS";

static unsigned bpage[MAXBLK];      /* page (EMS) ou segment (DOS) */
static unsigned blen[MAXBLK];       /* octets utilises */
static unsigned bnl[MAXBLK];        /* sauts de ligne */
static int nblk = 0;
static int cb = 0;                  /* dernier bloc trouve... */
static pos_t cstart = 0;            /* ...et sa position de depart */

static int ems = 0;
static unsigned h_ems = 0, frame = 0, ems_ver = 0, owned = 0;
static int map_saved = 0;
static unsigned freepg[MAXPG];      /* pages EMS libres */
static int nfree = 0;
static unsigned slotpg[4] = { NOPAGE, NOPAGE, NOPAGE, NOPAGE };
static unsigned long slotuse[4], tick = 0;

static unsigned stpg[NST][MAXST];   /* reserves : pages pleines, */
static int stn[NST];                /* sauf la derniere */
static pos_t stlen[NST];
static unsigned stbase[NST];        /* journaux : octets abandonnes dans la 1re page */

static int mem_dirty = 1;
static unsigned char bounce[512];

/* ------------------------------------------------------ copies */

/* Copie sans chevauchement */
static void fmove(unsigned char far *d, unsigned char far *s, unsigned n)
{
#ifdef __TURBOC__
    movedata(FP_SEG(s), FP_OFF(s), FP_SEG(d), FP_OFF(d), n);
#else
    while (n--) *d++ = *s++;
#endif
}

/* Decalage vers le haut dans un meme bloc (d > s), par la fin */
static void move_up(unsigned char far *d, unsigned char far *s, unsigned n)
{
    unsigned k;

    while (n) {
        k = n > sizeof bounce ? sizeof bounce : n;
        n -= k;
        fmove((unsigned char far *)bounce, s + n, k);
        fmove(d + n, (unsigned char far *)bounce, k);
    }
}

/* Decalage vers le bas dans un meme bloc (d < s), par le debut */
static void move_down(unsigned char far *d, unsigned char far *s, unsigned n)
{
    unsigned k;

    while (n) {
        k = n > sizeof bounce ? sizeof bounce : n;
        fmove((unsigned char far *)bounce, s, k);
        fmove(d, (unsigned char far *)bounce, k);
        d += k; s += k; n -= k;
    }
}

static unsigned nlc(unsigned char far *s, unsigned n)
{
    unsigned k = 0;

    while (n--)
        if (*s++ == '\n') k++;
    return k;
}

/* ------------------------------------------------------- pages */

static int ems_call(union REGS *r)
{
    int86(0x67, r, r);
    return r->h.ah == 0;
}

static int pg_alloc(unsigned *pg)
{
    union REGS r;
    unsigned want, k;

    if (!ems) {
        if (allocmem(BLKSZ >> 4, pg) != -1) return 0;
        mem_dirty = 1;
        return 1;
    }
    if (nfree == 0) {
        if (ems_ver < 0x40 || owned >= MAXPG) return 0;
        want = owned + GROW;
        if (want > MAXPG) want = MAXPG;
        r.h.ah = 0x51;                  /* agrandir le handle */
        r.x.bx = want;
        r.x.dx = h_ems;
        if (!ems_call(&r)) return 0;
        for (k = want; k > owned; k--) freepg[nfree++] = k - 1;
        owned = want;
        mem_dirty = 1;
    }
    *pg = freepg[--nfree];
    return 1;
}

static void pg_free(unsigned pg)
{
    if (!ems) {
        freemem(pg);
        mem_dirty = 1;
    } else
        freepg[nfree++] = pg;
}

/* Place la page dans l'emplacement donne du cadre */
static unsigned char far *pg_map(unsigned pg, int slot)
{
    union REGS r;
    int t;

    if (!ems)
        return (unsigned char far *)MK_FP(pg, 0);
    if (slotpg[slot] != pg) {
        for (t = 0; t < 4; t++)         /* pas deux emplacements pour une page */
            if (t != slot && slotpg[t] == pg) slotpg[t] = NOPAGE;
        r.h.ah = 0x44;
        r.h.al = (unsigned char)slot;
        r.x.bx = pg;
        r.x.dx = h_ems;
        int86(0x67, &r, &r);
        slotpg[slot] = pg;
    }
    slotuse[slot] = ++tick;
    return (unsigned char far *)MK_FP(frame + slot * 0x400, 0);
}

/* Lecture : emplacement 0 a 2 deja occupe par la page, sinon le plus ancien */
static unsigned char far *pg_get(unsigned pg)
{
    int s, best = 0;

    if (!ems)
        return (unsigned char far *)MK_FP(pg, 0);
    for (s = 0; s < 3; s++)
        if (slotpg[s] == pg) return pg_map(pg, s);
    for (s = 1; s < 3; s++)
        if (slotuse[s] < slotuse[best]) best = s;
    return pg_map(pg, best);
}

/* ------------------------------------------------------- table */

static void tbl_insert(int at, unsigned pg, unsigned len, unsigned nl)
{
    int i;

    for (i = nblk; i > at; i--) {
        bpage[i] = bpage[i - 1];
        blen[i] = blen[i - 1];
        bnl[i] = bnl[i - 1];
    }
    bpage[at] = pg;
    blen[at] = len;
    bnl[at] = nl;
    nblk++;
    cb = 0;
    cstart = 0;
}

static void tbl_remove(int at)
{
    int i;

    for (i = at; i < nblk - 1; i++) {
        bpage[i] = bpage[i + 1];
        blen[i] = blen[i + 1];
        bnl[i] = bnl[i + 1];
    }
    nblk--;
    cb = 0;
    cstart = 0;
}

/*
 * Bloc contenant la position p, et position dans ce bloc. Une position
 * situee entre deux blocs appartient au second ; la fin du texte
 * appartient au dernier bloc (*off = sa longueur).
 */
static int locate(pos_t p, unsigned *off)
{
    if (cb >= nblk) { cb = 0; cstart = 0; }
    while (cb > 0 && p < cstart) {
        cb--;
        cstart -= blen[cb];
    }
    while (cb < nblk - 1 && p >= cstart + blen[cb]) {
        cstart += blen[cb];
        cb++;
    }
    *off = (unsigned)(p - cstart);
    return cb;
}

/* Recolle le bloc i et le suivant s'ils tiennent dans un bloc */
static int try_merge(int i)
{
    unsigned char far *d, far *s;

    if (i < 0 || i + 1 >= nblk || blen[i] + blen[i + 1] > BLKSZ)
        return 0;
    d = pg_map(bpage[i], 0);
    s = pg_map(bpage[i + 1], 1);
    fmove(d + blen[i], s, blen[i + 1]);
    blen[i] += blen[i + 1];
    bnl[i] += bnl[i + 1];
    pg_free(bpage[i + 1]);
    tbl_remove(i + 1);
    return 1;
}

/* ---------------------------------------------- init et fin */

static int ems_init(void)
{
    static char name[] = "EMMXXXX0";
    union REGS r;
    unsigned seg, n, k;
    char far *p;
    int i;

    seg = *(unsigned short far *)MK_FP(0, 0x67 * 4 + 2);
    if (seg == 0) return 0;
    p = (char far *)MK_FP(seg, 10);
    for (i = 0; i < 8; i++)
        if (p[i] != name[i]) return 0;
    r.h.ah = 0x40;
    if (!ems_call(&r)) return 0;
    r.h.ah = 0x41;                      /* segment du cadre */
    if (!ems_call(&r)) return 0;
    frame = r.x.bx;
    r.h.ah = 0x46;                      /* version */
    ems_ver = ems_call(&r) ? r.h.al : 0;

    if (ems_ver >= 0x40)
        n = GROW;                       /* on agrandira a la demande */
    else {
        r.h.ah = 0x42;                  /* EMS 3.x : tout de suite */
        if (!ems_call(&r)) return 0;
        n = r.x.bx > MAXPG ? MAXPG : r.x.bx;
    }
    if (n == 0) return 0;
    r.h.ah = 0x43;
    r.x.bx = n;
    if (!ems_call(&r)) return 0;
    h_ems = r.x.dx;
    owned = n;
    for (k = n; k > 0; k--) freepg[nfree++] = k - 1;

    r.h.ah = 0x47;                      /* sauver le contexte du cadre */
    r.x.dx = h_ems;
    map_saved = ems_call(&r);
    ems = 1;
    return 1;
}

int buf_init(void)
{
    if (ems_init())
        buf_where = "EMS";
    else
        buf_where = "DOS";
    buf_reset();
    return 1;
}

/* Vide le texte (les reserves sont conservees) */
void buf_reset(void)
{
    while (nblk > 0) {
        pg_free(bpage[nblk - 1]);
        nblk--;
    }
    b_total = 0;
    cb = 0;
    cstart = 0;
}

void buf_done(void)
{
    union REGS r;
    int s;

    buf_reset();
    for (s = 0; s < NST; s++)
        st_clear(s);
    if (ems) {
        if (map_saved) { r.h.ah = 0x48; r.x.dx = h_ems; ems_call(&r); }
        r.h.ah = 0x45;
        r.x.dx = h_ems;
        ems_call(&r);
        ems = 0;
    }
}

/* -------------------------------------------------- lecture */

int buf_at(pos_t p)
{
    unsigned o;
    int b = locate(p, &o);

    return pg_get(bpage[b])[o];
}

/* Pointeur sur la position p et nombre d'octets contigus qui suivent */
unsigned char far *buf_span(pos_t p, unsigned *n)
{
    unsigned o;
    int b;

    if (p < 0 || p >= b_total) {
        *n = 0;
        return (unsigned char far *)0;
    }
    b = locate(p, &o);
    *n = blen[b] - o;
    return pg_get(bpage[b]) + o;
}

/* ------------------------------------------------- insertion */

/*
 * Insere n octets (n <= BLKSZ) en p. La source est en memoire proche
 * ou dans l'emplacement 3 du cadre ; les blocs du texte utilisent les
 * emplacements 0 et 1. Rend 0, sans rien modifier, si la memoire manque.
 */
static int ins_chunk(pos_t p, unsigned char far *src, unsigned n)
{
    unsigned o, len, tail, c, tailnl = 0, pg[2];
    unsigned char far *d, far *t;
    int b, extra, i, at;

    if (n == 0) return 1;
    if (nblk == 0) {
        if (!pg_alloc(&pg[0])) return 0;
        tbl_insert(0, pg[0], 0, 0);
    }
    b = locate(p, &o);
    len = blen[b];

    if (len + n <= BLKSZ) {             /* cas courant : ca tient */
        d = pg_map(bpage[b], 0);
        if (o < len) move_up(d + o + n, d + o, len - o);
        fmove(d + o, src, n);
        blen[b] = len + n;
        bnl[b] += nlc(src, n);
        b_total += n;
        return 1;
    }

    /* Bloc plein : la fin du bloc part dans un nouveau bloc */
    tail = len - o;
    c = BLKSZ - o;
    if (c > n) c = n;
    extra = (n > c) + (tail > 0);
    if (nblk + extra > MAXBLK) return 0;
    for (i = 0; i < extra; i++)
        if (!pg_alloc(&pg[i])) {
            while (i > 0) pg_free(pg[--i]);
            return 0;
        }

    d = pg_map(bpage[b], 0);
    if (tail) {
        t = pg_map(pg[extra - 1], 1);
        fmove(t, d + o, tail);
        tailnl = nlc(t, tail);
        bnl[b] -= tailnl;
    }
    fmove(d + o, src, c);
    blen[b] = o + c;
    bnl[b] += nlc(src, c);
    at = b + 1;
    if (n > c) {                        /* le reste dans un bloc neuf */
        t = pg_map(pg[0], 1);
        fmove(t, src + c, n - c);
        tbl_insert(at++, pg[0], n - c, nlc(src + c, n - c));
    }
    if (tail) {
        tbl_insert(at, pg[extra - 1], tail, tailnl);
        try_merge(at);                  /* fin + bloc suivant */
    } else
        try_merge(at - 1);              /* bloc neuf + bloc suivant */
    b_total += n;
    return 1;
}

int buf_ins(pos_t p, char *s, unsigned n)
{
    unsigned k;

    while (n) {
        k = n > BLKSZ ? BLKSZ : n;
        if (!ins_chunk(p, (unsigned char far *)s, k)) return 0;
        p += k; s += k; n -= k;
    }
    return 1;
}

int buf_insch(pos_t p, int c)
{
    static char one[1];

    one[0] = (char)c;
    return ins_chunk(p, (unsigned char far *)one, 1);
}

/* ------------------------------------------------- suppression */

void buf_del(pos_t p, pos_t n)
{
    unsigned o, k, len, nl;
    unsigned char far *d;
    int b;

    if (p < 0 || p >= b_total || n <= 0) return;
    if (n > b_total - p) n = b_total - p;
    while (n > 0) {
        b = locate(p, &o);
        len = blen[b];
        k = (n < (pos_t)(len - o)) ? (unsigned)n : len - o;
        if (o == 0 && k == len) {       /* bloc entier */
            pg_free(bpage[b]);
            tbl_remove(b);
        } else {
            d = pg_map(bpage[b], 0);
            nl = nlc(d + o, k);
            if (o + k < len) move_down(d + o, d + o + k, len - o - k);
            blen[b] = len - k;
            bnl[b] -= nl;
        }
        b_total -= k;
        n -= k;
    }
    if (nblk > 1) {                     /* recoller autour du point */
        b = locate(p, &o);
        if (b > 0 && try_merge(b - 1)) b--;
        try_merge(b);
    }
}

/* ------------------------------------------------------- reserves */

void st_clear(int s)
{
    while (stn[s] > 0)
        pg_free(stpg[s][--stn[s]]);
    stlen[s] = 0;
    stbase[s] = 0;
}

pos_t st_len(int s)
{
    return stlen[s];
}

/* Alloue les pages pour n octets (reserve vide au depart) */
static int st_alloc(int s, pos_t n)
{
    int k, need = (int)((n + BLKSZ - 1) / BLKSZ);

    if (need > MAXST) return 0;
    for (k = 0; k < need; k++)
        if (!pg_alloc(&stpg[s][k])) {
            stn[s] = k;
            st_clear(s);
            return 0;
        }
    stn[s] = need;
    return 1;
}

/* Copie [a, b) du texte dans la reserve ; a == b la vide */
int st_set(int s, pos_t a, pos_t b)
{
    pos_t n = b - a;
    unsigned m, done, take, sn;
    unsigned char far *d, far *src;
    int k;

    st_clear(s);
    if (n < 0 || a < 0 || b > b_total) return 0;
    if (!st_alloc(s, n)) return 0;
    for (k = 0; k < stn[s]; k++) {
        m = (k < stn[s] - 1) ? BLKSZ : (unsigned)(n - (pos_t)k * BLKSZ);
        done = 0;
        while (done < m) {
            src = buf_span(a, &sn);     /* emplacements 0 a 2 */
            d = pg_map(stpg[s][k], 3);
            take = m - done;
            if (take > sn) take = sn;
            fmove(d + done, src, take);
            done += take;
            a += take;
        }
    }
    stlen[s] = n;
    return 1;
}

/* Copie les n premiers octets de la reserve src dans d (remplacee) */
int st_copy(int d, int src, pos_t n)
{
    pos_t o = 0;
    unsigned k, off;
    unsigned char far *p;

    st_clear(d);
    if (n > stlen[src]) n = stlen[src];
    if (!st_alloc(d, n)) return 0;
    while (o < n) {
        off = (unsigned)(o % BLKSZ);
        k = sizeof bounce;
        if ((pos_t)k > n - o) k = (unsigned)(n - o);
        if (k > BLKSZ - off) k = BLKSZ - off;
        p = pg_map(stpg[src][(int)(o / BLKSZ)], 3);
        fmove((unsigned char far *)bounce, p + off, k);
        p = pg_map(stpg[d][(int)(o / BLKSZ)], 3);
        fmove(p + off, (unsigned char far *)bounce, k);
        o += k;
    }
    stlen[d] = n;
    return 1;
}

/* Ajoute un octet a la fin */
int st_putc(int s, int c)
{
    unsigned char far *p;

    if (stlen[s] == (pos_t)stn[s] * BLKSZ) {
        if (stn[s] >= MAXST || !pg_alloc(&stpg[s][stn[s]])) return 0;
        stn[s]++;
    }
    p = pg_map(stpg[s][stn[s] - 1], 3);
    p[(unsigned)(stlen[s] - (pos_t)(stn[s] - 1) * BLKSZ)] = (unsigned char)c;
    stlen[s]++;
    return 1;
}

/* Retire le dernier octet */
void st_unputc(int s)
{
    if (stlen[s] == 0) return;
    stlen[s]--;
    if (stlen[s] == (pos_t)(stn[s] - 1) * BLKSZ)
        pg_free(stpg[s][--stn[s]]);
}

/* Ajoute un octet au debut ; seulement si la reserve tient dans une
   page (rend 0 sinon, sans rien changer) */
int st_pushc(int s, int c)
{
    unsigned char far *p;

    if (stlen[s] >= BLKSZ) return 0;
    if (stn[s] == 0) {
        if (!pg_alloc(&stpg[s][0])) return 0;
        stn[s] = 1;
    }
    p = pg_map(stpg[s][0], 3);
    if (stlen[s]) move_up(p + 1, p, (unsigned)stlen[s]);
    p[0] = (unsigned char)c;
    stlen[s]++;
    return 1;
}

/* Insere la reserve en p ; rend le nombre d'octets inseres (moins si
   memoire pleine) */
pos_t st_insert(int s, pos_t p)
{
    pos_t done = 0;
    unsigned m;
    int k;

    for (k = 0; k < stn[s]; k++) {
        m = (k < stn[s] - 1) ? BLKSZ : (unsigned)(stlen[s] - (pos_t)k * BLKSZ);
        if (!ins_chunk(p + done, pg_map(stpg[s][k], 3), m)) break;
        done += m;
    }
    return done;
}

/* ------------------------------------------------------- journaux */

/*
 * Un journal est une pile de modifications dans une reserve. Chaque
 * enregistrement est : [en-tete 12][texte supprime][texte insere][en-tete 12]
 * (position, longueur supprimee, longueur inseree). L'en-tete est aux
 * deux bouts : on depile par le sommet (annuler) et on oublie par le
 * pied (les plus anciennes) en rendant les pages du debut.
 * stbase[j] = octets du debut de la premiere page deja abandonnes.
 */
#define JHDR 12

pos_t jn_len(int j)
{
    return stlen[j] - stbase[j];
}

static void put32(unsigned char *d, pos_t v)
{
    d[0] = (unsigned char)v;
    d[1] = (unsigned char)(v >> 8);
    d[2] = (unsigned char)(v >> 16);
    d[3] = (unsigned char)(v >> 24);
}

static pos_t get32(unsigned char *s)
{
    return (pos_t)s[0] | ((pos_t)s[1] << 8) | ((pos_t)s[2] << 16) |
           ((pos_t)s[3] << 24);
}

/* Lit n octets a la position absolue a de la reserve s */
static void st_rd(int s, pos_t a, unsigned char *dst, unsigned n)
{
    unsigned off, k;
    unsigned char far *p;

    while (n) {
        off = (unsigned)(a % BLKSZ);
        k = BLKSZ - off;
        if (k > n) k = n;
        p = pg_map(stpg[s][(int)(a / BLKSZ)], 3);
        fmove((unsigned char far *)dst, p + off, k);
        a += k;
        dst += k;
        n -= k;
    }
}

/* Ajoute n octets a la fin de la reserve s */
static int st_putn(int s, unsigned char *src, unsigned n)
{
    unsigned off, k;
    unsigned char far *p;

    while (n) {
        if (stlen[s] == (pos_t)stn[s] * BLKSZ) {
            if (stn[s] >= MAXST || !pg_alloc(&stpg[s][stn[s]])) return 0;
            stn[s]++;
        }
        off = (unsigned)(stlen[s] - (pos_t)(stn[s] - 1) * BLKSZ);
        k = BLKSZ - off;
        if (k > n) k = n;
        p = pg_map(stpg[s][stn[s] - 1], 3);
        fmove(p + off, (unsigned char far *)src, k);
        stlen[s] += k;
        src += k;
        n -= k;
    }
    return 1;
}

/* Ajoute a d les n premiers octets de la reserve src */
static int st_app(int d, int src, pos_t n)
{
    pos_t o = 0;
    unsigned k, off;
    unsigned char far *p;

    while (o < n) {
        off = (unsigned)(o % BLKSZ);
        k = sizeof bounce;
        if ((pos_t)k > n - o) k = (unsigned)(n - o);
        if (k > BLKSZ - off) k = BLKSZ - off;
        p = pg_map(stpg[src][(int)(o / BLKSZ)], 3);
        fmove((unsigned char far *)bounce, p + off, k);
        if (!st_putn(d, bounce, k)) return 0;
        o += k;
    }
    return 1;
}

/* Remplace d par les n octets de src a partir de la position absolue a */
static int st_cprange(int d, int src, pos_t a, pos_t n)
{
    pos_t o = 0;
    unsigned k, soff, doff;
    unsigned char far *p;

    st_clear(d);
    if (!st_alloc(d, n)) return 0;
    while (o < n) {
        soff = (unsigned)((a + o) % BLKSZ);
        doff = (unsigned)(o % BLKSZ);
        k = sizeof bounce;
        if ((pos_t)k > n - o) k = (unsigned)(n - o);
        if (k > BLKSZ - soff) k = BLKSZ - soff;
        if (k > BLKSZ - doff) k = BLKSZ - doff;
        p = pg_map(stpg[src][(int)((a + o) / BLKSZ)], 3);
        fmove((unsigned char far *)bounce, p + soff, k);
        p = pg_map(stpg[d][(int)(o / BLKSZ)], 3);
        fmove(p + doff, (unsigned char far *)bounce, k);
        o += k;
    }
    stlen[d] = n;
    return 1;
}

/* Raccourcit la reserve s a la position absolue a (pages rendues) */
static void st_cut(int s, pos_t a)
{
    int need;

    if (a <= (pos_t)stbase[s]) {
        st_clear(s);
        return;
    }
    need = (int)((a + BLKSZ - 1) / BLKSZ);
    while (stn[s] > need)
        pg_free(stpg[s][--stn[s]]);
    stlen[s] = a;
}

/* Empile la modification (p, ST_UDEL, ST_UINS) ; rien n'est change si
   la memoire manque */
int jn_push(int j, pos_t p)
{
    unsigned char h[JHDR];
    pos_t old = stlen[j];

    put32(h, p);
    put32(h + 4, stlen[ST_UDEL]);
    put32(h + 8, stlen[ST_UINS]);
    if (st_putn(j, h, JHDR) &&
        st_app(j, ST_UDEL, stlen[ST_UDEL]) &&
        st_app(j, ST_UINS, stlen[ST_UINS]) &&
        st_putn(j, h, JHDR))
        return 1;
    st_cut(j, old);
    return 0;
}

/* Depile le sommet dans ST_UDEL / ST_UINS (remplaces) */
int jn_pop(int j, pos_t *p)
{
    unsigned char h[JHDR];
    pos_t e = stlen[j], nd, ni, sz;

    if (jn_len(j) < 2 * JHDR) return 0;
    st_rd(j, e - JHDR, h, JHDR);
    nd = get32(h + 4);
    ni = get32(h + 8);
    sz = 2 * JHDR + nd + ni;
    if (nd < 0 || ni < 0 || sz > jn_len(j)) {   /* ne devrait jamais arriver */
        st_clear(j);
        return 0;
    }
    *p = get32(h);
    if (!st_cprange(ST_UINS, j, e - JHDR - ni, ni) ||
        !st_cprange(ST_UDEL, j, e - JHDR - ni - nd, nd)) {
        st_clear(ST_UINS);
        st_clear(ST_UDEL);
        return 0;
    }
    st_cut(j, e - sz);
    return 1;
}

/* Oublie les plus anciennes modifications jusqu'a rendre au moins une
   page ; rend 0 si le journal etait vide */
int jn_drop_oldest(int j)
{
    unsigned char h[JHDR];
    pos_t sz, nb;
    int freed = 0, k;

    if (jn_len(j) < 2 * JHDR) {
        st_clear(j);
        return 0;
    }
    while (!freed) {
        st_rd(j, (pos_t)stbase[j], h, JHDR);
        sz = 2 * JHDR + get32(h + 4) + get32(h + 8);
        if (get32(h + 4) < 0 || get32(h + 8) < 0 || sz >= jn_len(j)) {
            st_clear(j);                /* tout y passe */
            return 1;
        }
        nb = stbase[j] + sz;
        while (nb >= BLKSZ) {
            pg_free(stpg[j][0]);
            for (k = 1; k < stn[j]; k++) stpg[j][k - 1] = stpg[j][k];
            stn[j]--;
            stlen[j] -= BLKSZ;
            nb -= BLKSZ;
            freed = 1;
        }
        stbase[j] = (unsigned)nb;
    }
    return 1;
}

/* Presse-papiers */
pos_t buf_cliplen(void)        { return stlen[ST_CLIP]; }
int   buf_setclip(pos_t a, pos_t b) { return st_set(ST_CLIP, a, b); }
pos_t buf_paste(pos_t p)       { return st_insert(ST_CLIP, p); }

/* ------------------------------------------------- recherches */

pos_t buf_count(pos_t a, pos_t e, int ch)
{
    pos_t k = 0, pos = a;
    unsigned o, m, i;
    unsigned char far *s;
    unsigned char c = (unsigned char)ch;
    int b;

    if (a < 0) a = pos = 0;
    if (e > b_total) e = b_total;
    if (pos >= e) return 0;
    b = locate(pos, &o);
    while (pos < e && b < nblk) {
        m = blen[b] - o;
        if ((pos_t)m > e - pos) m = (unsigned)(e - pos);
        if (ch == '\n' && o == 0 && m == blen[b])
            k += bnl[b];                /* bloc entier : compteur */
        else if (m) {
            s = pg_get(bpage[b]) + o;
            for (i = m; i; i--)
                if (*s++ == c) k++;
        }
        pos += m;
        b++;
        o = 0;
    }
    return k;
}

/* Premiere occurrence de ch a partir de p, ou NOPOS */
pos_t buf_find(pos_t p, int ch)
{
    unsigned o, i;
    unsigned char far *s;
    unsigned char c = (unsigned char)ch;
    pos_t start;
    int b;

    if (p < 0) p = 0;
    if (p >= b_total) return NOPOS;
    b = locate(p, &o);
    start = p - o;
    for (; b < nblk; start += blen[b], b++, o = 0) {
        if (ch == '\n' && bnl[b] == 0) continue;
        s = pg_get(bpage[b]);
        for (i = o; i < blen[b]; i++)
            if (s[i] == c) return start + i;
    }
    return NOPOS;
}

/* Derniere occurrence de ch strictement avant p, ou NOPOS */
pos_t buf_rfind(pos_t p, int ch)
{
    unsigned o, i;
    unsigned char far *s;
    unsigned char c = (unsigned char)ch;
    pos_t start;
    int b;

    if (p > b_total) p = b_total;
    if (p <= 0) return NOPOS;
    b = locate(p - 1, &o);
    start = (p - 1) - o;
    i = o + 1;                          /* octets [0, i) a examiner */
    for (;;) {
        if (!(ch == '\n' && bnl[b] == 0)) {
            s = pg_get(bpage[b]);
            while (i > 0) {
                i--;
                if (s[i] == c) return start + i;
            }
        }
        if (b == 0) return NOPOS;
        b--;
        start -= blen[b];
        i = blen[b];
    }
}

static int lower(int c)
{
    return (c >= 'A' && c <= 'Z') ? c + 32 : c;
}

/* Recherche sans distinction de casse (ASCII), a partir de from */
pos_t buf_search(pos_t from, char *pat, int n)
{
    unsigned o, i;
    unsigned char far *s;
    pos_t start;
    int b, j, c0;

    if (n <= 0 || from < 0 || from + n > b_total) return NOPOS;
    c0 = lower((unsigned char)pat[0]);
    b = locate(from, &o);
    start = from - o;
    for (; b < nblk; start += blen[b], b++, o = 0) {
        s = pg_get(bpage[b]);
        for (i = o; i < blen[b]; i++) {
            if (lower(s[i]) != c0) continue;
            if (start + i + n > b_total) return NOPOS;
            for (j = 1; j < n; j++)
                if (lower(buf_at(start + i + j)) != lower((unsigned char)pat[j]))
                    break;
            if (j == n) return start + i;
            s = pg_get(bpage[b]);       /* buf_at() a pu changer le cadre */
        }
    }
    return NOPOS;
}

/* ------------------------------------------- occupation memoire */

/*
 * Memoire consommee par ED, en Ko arrondis :
 *   *conv : blocs DOS sous A000h appartenant a notre PSP (programme,
 *           environnement, blocs de texte sans EMS), en-tetes compris ;
 *   *high : pages EMS reservees (16 Ko chacune).
 */
void buf_mem(unsigned *conv, unsigned *high)
{
    static unsigned kconv = 0;
    union REGS r;
    struct SREGS s;
    unsigned seg, size, owner, pc = 0, n;
    unsigned char type;

    if (mem_dirty) {
        r.h.ah = 0x52;                  /* liste des listes : ES:BX */
        segread(&s);
        int86x(0x21, &r, &r, &s);
        seg = *(unsigned short far *)MK_FP(s.es, r.x.bx - 2);
        for (n = 0; n < 2000; n++) {
            type = *(unsigned char far *)MK_FP(seg, 0);
            owner = *(unsigned short far *)MK_FP(seg, 1);
            size = *(unsigned short far *)MK_FP(seg, 3);
            if (type != 'M' && type != 'Z') break;
            if (seg >= 0xA000) break;
            if (owner == _psp) pc += size + 1;
            if (type == 'Z' || seg + size + 1 < seg) break;
            seg += size + 1;
        }
        kconv = (pc + 32) / 64;         /* 64 paragraphes = 1 Ko */
        mem_dirty = 0;
    }
    *conv = kconv;
    *high = ems ? owned * 16 : 0;
}

/* --------------------------------------------- controle interne */

/*
 * Verifie la coherence de la table (pour TEST) : longueurs, total,
 * compteurs de sauts de ligne. Rend 0 si tout va bien, sinon un code.
 */
int buf_check(void)
{
    pos_t sum = 0;
    int b;

    for (b = 0; b < nblk; b++) {
        if (blen[b] == 0 || blen[b] > BLKSZ) return 1;
        if (nlc(pg_get(bpage[b]), blen[b]) != bnl[b]) return 2;
        sum += blen[b];
    }
    if (sum != b_total) return 3;
    for (b = 0; b < NST; b++)
        if (stbase[b] >= BLKSZ || stlen[b] < stbase[b] ||
            stlen[b] > (pos_t)stn[b] * BLKSZ ||
            (stn[b] > 0 && stlen[b] <= (pos_t)(stn[b] - 1) * BLKSZ))
            return 4;
    return 0;
}
