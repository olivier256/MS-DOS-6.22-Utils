@echo off
rem Compile ED.EXE (Turbo C 2.0, modele small) : voir MAKEFILE.
rem Les OBJ sont gardes dans OBJ ; seuls les fichiers modifies sont recompiles.
rem Pour tout recompiler : del OBJ\*.OBJ puis MAKE.
if not exist OBJ\nul md OBJ
make.exe ED.EXE
