/*
 * SCR.C - Ecran en ecriture directe dans la memoire video
 *
 * On compose l'image dans scr_sh (copie de travail en memoire
 * proche), puis scr_flush() n'ecrit en memoire video que les
 * cellules qui ont change depuis la derniere fois (scr_on).
 * Le BIOS (INT 10h) ne sert qu'a lire le mode et a placer ou
 * dessiner le curseur.
 */

#include <dos.h>
#include "ed.h"

cell_t scr_sh[SCOLS * SROWS];           /* image en preparation */

static cell_t scr_on[SCOLS * SROWS];    /* image deja a l'ecran */
static cell_t far *vram;
static int cur_r = -1, cur_c = -1, cur_ins = -1;
static unsigned orig_shape;

/*
 * Ecran 80x25 texte uniquement. Si le mode courant n'est pas
 * 80x25 (40 colonnes, 43/50 lignes, graphique), on repasse en
 * mode 3 ; DISPLAY.SYS recharge alors la page de codes active.
 */
int scr_init(void)
{
    union REGS r;
    unsigned off, rows;
    int mode, i;

    r.h.ah = 0x0F;
    int86(0x10, &r, &r);
    mode = r.h.al & 0x7F;
    rows = *(unsigned char far *)MK_FP(0x40, 0x84);   /* 0 avant l'EGA */
    if (mode != 7 && ((mode != 3 && mode != 2) || r.h.ah != SCOLS ||
                      (rows != 0 && rows != SROWS - 1))) {
        r.x.ax = 0x0003;
        int86(0x10, &r, &r);
        mode = 3;
    }
    off = *(unsigned short far *)MK_FP(0x40, 0x4E);   /* page active */
    vram = (cell_t far *)MK_FP(mode == 7 ? 0xB000 : 0xB800, off);

    r.h.ah = 0x03;
    r.h.bh = 0;
    int86(0x10, &r, &r);
    orig_shape = r.x.cx;
    if (orig_shape & 0x2000)            /* curseur cache au lancement */
        orig_shape = (mode == 7) ? 0x0B0C : 0x0607;

    for (i = 0; i < SCOLS * SROWS; i++) {
        scr_sh[i] = (A_TEXT << 8) | ' ';
        scr_on[i] = 0;                  /* force le premier affichage */
    }
    return 1;
}

void scr_flush(void)
{
    register unsigned i;
    unsigned n = SCOLS * SROWS;
    cell_t *s = scr_sh, *o = scr_on;
    cell_t far *v = vram;

    for (i = 0; i < n; i++)
        if (s[i] != o[i]) {
            o[i] = s[i];
            v[i] = s[i];
        }
}

void scr_cursor(int row, int col)
{
    union REGS r;

    if (row == cur_r && col == cur_c)
        return;
    cur_r = row;
    cur_c = col;
    r.h.ah = 0x02;
    r.h.bh = 0;
    r.h.dh = (unsigned char)row;
    r.h.dl = (unsigned char)col;
    int86(0x10, &r, &r);
}

/* Insertion : forme d'origine (souligne) ; remplacement : pave */
void scr_shape(int insert)
{
    union REGS r;

    if (insert == cur_ins)
        return;
    cur_ins = insert;
    r.h.ah = 0x01;
    r.x.cx = insert ? orig_shape : (orig_shape & 0x00FF);
    int86(0x10, &r, &r);
}

void scr_puts(int row, int col, char *s, int attr)
{
    cell_t *d = scr_sh + row * SCOLS + col;

    while (*s && col < SCOLS) {
        *d++ = (cell_t)((attr << 8) | (unsigned char)*s++);
        col++;
    }
}

void scr_fill(int row, int col, int n, int ch, int attr)
{
    cell_t *d = scr_sh + row * SCOLS + col;
    cell_t v = (cell_t)((attr << 8) | (unsigned char)ch);

    while (n-- > 0 && col++ < SCOLS)
        *d++ = v;
}

void scr_done(void)
{
    union REGS r;
    int i;

    for (i = 0; i < SROWS; i++)
        scr_fill(i, 0, SCOLS, ' ', 0x07);  /* ecran DOS normal */
    scr_flush();
    cur_r = -1;
    scr_cursor(0, 0);
    r.h.ah = 0x01;
    r.x.cx = orig_shape;
    int86(0x10, &r, &r);
}
